import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { FaBars, FaTimes } from "react-icons/fa";

const Navbar = () => {
    const [isOpen, setIsOpen] = useState(false);
    const location = useLocation(); // Hook to get the current location

    const toggleMenu = () => {
        setIsOpen(!isOpen);
    };

    // Function to determine if a link is active
    const isActive = (path) => location.pathname === path;

    return (
        <header className="bg-blue-500 text-white shadow-md relative">
            {/* Navbar Container */}
            <div className="container mx-auto flex items-center justify-between p-4">
                {/* Logo Section */}
                <div className="flex-shrink-0">
                    <h1 className="text-lg font-bold">QR Manager</h1>
                </div>

                {/* Navigation Links */}
                <nav className="hidden md:flex flex-grow justify-center items-center space-x-6">
                    <Link
                        to="/"
                        className={`${isActive("/") ? "text-blue-300 underline" : "hover:text-blue-300"
                            } transition duration-300 ease-in-out transform hover:scale-105`}
                    >
                        Home
                    </Link>
                    <Link
                        to="/"
                        className={`${isActive("/about") ? "text-blue-300 underline" : "hover:text-blue-300"
                            } transition duration-300 ease-in-out transform hover:scale-105`}
                    >
                        About
                    </Link>
                    <Link
                        to="/"
                        className={`${isActive("/contact") ? "text-blue-300 underline" : "hover:text-blue-300"
                            } transition duration-300 ease-in-out transform hover:scale-105`}
                    >
                        Contact
                    </Link>
                </nav>

                {/* Buttons for Login/Register */}
                <div className="hidden md:flex justify-end items-center space-x-4">
                    <Link to="/login"><button className="bg-blue-600 py-1 px-4 rounded hover:bg-blue-700">
                        Log In
                    </button></Link>
                    <Link to="/register"> <button className="bg-gray-100 text-blue-500 py-1 px-4 rounded hover:bg-gray-200">
                        Register
                    </button></Link>


                </div>

                {/* Mobile Menu Toggle */}
                <button
                    onClick={toggleMenu}
                    className="md:hidden p-2 bg-blue-600 rounded focus:outline-none"
                >
                    {isOpen ? <FaTimes size={20} /> : <FaBars size={20} />}
                </button>
            </div>

            {/* Mobile Navigation Overlay */}
            <div
                className={`fixed top-0 right-0 h-full w-3/4 bg-blue-600 transform ${isOpen ? "translate-x-0" : "translate-x-full"
                    } transition-transform duration-300 ease-in-out z-50`}
            >
                <button
                    onClick={toggleMenu}
                    className="absolute top-4 right-4 p-2 text-white"
                >
                    <FaTimes size={20} />
                </button>
                <nav className="flex flex-col items-center justify-center h-full space-y-6">
                    <Link
                        to="/"
                        onClick={toggleMenu}
                        className={`${isActive("/") ? "text-blue-300 underline" : "text-white"
                            } text-lg hover:text-blue-300 transition duration-300`}
                    >
                        Home
                    </Link>
                    <Link
                        to="/"
                        onClick={toggleMenu}
                        className={`${isActive("/about") ? "text-blue-300 underline" : "text-white"
                            } text-lg hover:text-blue-300 transition duration-300`}
                    >
                        About
                    </Link>
                    <Link
                        to="/"
                        onClick={toggleMenu}
                        className={`${isActive("/contact") ? "text-blue-300 underline" : "text-white"
                            } text-lg hover:text-blue-300 transition duration-300`}
                    >
                        Contact
                    </Link>
                    <div className="space-y-4">
                        <Link to="/login"><button className="w-full bg-blue-700 py-2 rounded hover:bg-blue-800">
                            Log In
                        </button></Link>
                        <Link to="/login"><button className="w-full bg-gray-200 text-blue-700 py-2 rounded hover:bg-gray-300">
                            Register
                        </button></Link>
                    </div>
                </nav>
            </div>
        </header>
    );
};

export default Navbar;
