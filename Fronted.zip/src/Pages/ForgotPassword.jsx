import { useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

const ForgotPassword = () => {
    const [step, setStep] = useState(1);
    const [email, setEmail] = useState("");
    const [otp, setOtp] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const navigate = useNavigate();

    const emailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
    const otpRegex = /^[0-9]+$/;
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,18}$/;

    const sendOtp = async (e) => {
        e.preventDefault();
        if (!emailRegex.test(email.trim())) {
            return toast.error("Enter a valid Gmail address (no spaces)");
        }

        try {
            const response = await axios.post("http://localhost:8080/api/auth/send-otp", { username: email.trim() });
            toast.success(response.data.message);
            await new Promise(resolve => setTimeout(resolve, 500));
            setStep(2);
        } catch (error) {
            toast.error(error.response?.data?.message || "Error sending OTP");
        }
    };

    const verifyOtp = async (e) => {
        e.preventDefault();
        if (!otpRegex.test(otp.trim())) {
            return toast.error("OTP must be a numeric value");
        }

        try {
            const response = await axios.post("http://localhost:8080/api/auth/verify-otp", { email, otp: otp.trim() });
            toast.success(response.data.message);
            await new Promise(resolve => setTimeout(resolve, 500));
            setStep(3);
        } catch (error) {
            toast.error(error.response?.data?.message || "Invalid OTP");
        }
    };

    const resetPassword = async (e) => {
        e.preventDefault();
        if (!passwordRegex.test(newPassword.trim())) {
            return toast.error("Password must be 8-18 characters long, with at least one uppercase letter, one number, and one special character.");
        }

        try {
            const response = await axios.post("http://localhost:8080/api/auth/reset-password", { email, newPassword: newPassword.trim() });
            toast.success(response.data.message);
            await new Promise(resolve => setTimeout(resolve, 500));
            setStep(1);
            setEmail("");
            setOtp("");
            setNewPassword("");
            navigate("/login");
        } catch (error) {
            toast.error(error.response?.data?.message || "Error resetting password");
        }
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-100">
            <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
                <h2 className="text-2xl font-bold text-center mb-4">
                    {step === 1 ? "Forgot Password" : step === 2 ? "Verify OTP" : "Reset Password"}
                </h2>

                {step === 1 && (
                    <form onSubmit={sendOtp} className="space-y-4">
                        <input
                            type="email"
                            placeholder="Enter your Gmail address"
                            className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring focus:ring-blue-300"
                            value={email}
                            onChange={(e) => setEmail(e.target.value.trim())}
                            required
                        />
                        <button type="submit" className="w-full bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600 transition">
                            Send OTP
                        </button>
                    </form>
                )}

                {step === 2 && (
                    <form onSubmit={verifyOtp} className="space-y-4">
                        <input
                            type="text"
                            placeholder="Enter OTP"
                            className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring focus:ring-blue-300"
                            value={otp}
                            onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))} // Removes non-numeric characters
                            required
                            minLength={6}
                            maxLength={6}
                            inputMode="numeric"
                            pattern="\d*"
                        />
                        <button type="submit" className="w-full bg-green-500 text-white py-2 rounded-md hover:bg-green-600 transition">
                            Verify OTP
                        </button>
                    </form>
                )}

                {step === 3 && (
                    <form onSubmit={resetPassword} className="space-y-4">
                        <input
                            type="password"
                            placeholder="Enter new password"
                            className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring focus:ring-blue-300"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value.trim())}
                            required
                            pattern={passwordRegex.source}
                            title="Must contain 8-18 characters, one uppercase letter, one number & one special character"
                        />
                        <button type="submit" className="w-full bg-purple-500 text-white py-2 rounded-md hover:bg-purple-600 transition">
                            Reset Password
                        </button>
                    </form>
                )}
            </div>
        </div>
    );
};

export default ForgotPassword;
