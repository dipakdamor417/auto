import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-blue-500 text-white py-4">
      <div className="container mx-auto text-center">
        <p>&copy; 2024 Your Company. All rights reserved.</p>
        <p>Follow us on <Link to="/" className="underline">Social Media</Link></p>
      </div>
    </footer>
  );
};

export default Footer;
