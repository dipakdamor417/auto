import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useDispatch } from 'react-redux';
import { loginFailure, loginStart, loginSuccess } from '../Redux/userSlice';
import { toast } from 'react-toastify';
import { FaEye, FaEyeSlash } from 'react-icons/fa';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [emailError, setEmailError] = useState(false);
  const [passwordError, setPasswordError] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const validateInputs = () => {
    let isValid = true;

    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      setEmailError(true);
      console.log(error);
      isValid = false;
    } else {
      setEmailError(false);
    }

    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,18}$/;
    if (!password || !passwordRegex.test(password)) {
      setPasswordError(true);
      isValid = false;
    } else {
      setPasswordError(false);
    }

    return isValid;
  };
  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');

    if (!validateInputs()) {
      toast.info("Please enter valid details before submitting.");
      return;
    }

    setLoading(true);
    dispatch(loginStart());

    try {
      const response = await axios.post(
        'http://localhost:8080/api/auth/login',
        { email, password },
        { withCredentials: true }
      );
      dispatch(loginSuccess(response.data));
      toast.success("Login successful!");
      navigate('/dashboard')
    } catch (err) {
      console.error("Login error:", err.response);
      dispatch(loginFailure());

      let errorMessage = "An error occurred during login.";
      if (err.response) {
        console.error("Error Response:", err.response.data);
        if (err.response.status === 400) {
          errorMessage = "Email and password are required!";
        } else if (err.response.status === 404) {
          errorMessage = "User not found!";
        } else if (err.response.status === 403) {
          errorMessage = "Your account is inactive. Please contact the administrator.";
        } else if (err.response.status === 401) {
          errorMessage = "Incorrect credentials!";
        } else {
          errorMessage = err.response.data?.error || errorMessage;
        }
      }

      setError(errorMessage);
      toast.error(errorMessage);
    }
    finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
      <div className="w-full max-w-md bg-white p-8 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold text-center mb-6">Log In</h2>
        <form onSubmit={handleLogin} className="space-y-4">
          {/* Email Field */}
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-600">
              Email
            </label>
            <input
              placeholder="Enter your Email"
              type="email"
              id="email"
              value={email}
              onChange={(e) => {
                const val = e.target.value;
                setEmail(val);
                setEmailError(!/\S+@\S+\.\S+/.test(val));
              }}
              required
              className={`w-full p-3 mt-2 border rounded-lg focus:outline-none focus:ring-2 ${emailError ? "border-red-500 focus:ring-red-500" : "border-gray-300 focus:ring-blue-500"
                }`}
            />
            {emailError && <p className="text-sm text-red-500 mt-1">Invalid email format</p>}
          </div>

          <div className="relative">
            <label htmlFor="password" className="block text-sm font-medium text-gray-600">
              Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                id="password"
                value={password}
                onChange={(e) => {
                  const val = e.target.value;
                  setPassword(val);
                  const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,18}$/;
                  setPasswordError(!passwordRegex.test(val));
                }}
                placeholder="Enter your password"
                required
                className={`w-full p-3 pr-10 mt-2 border rounded-lg focus:outline-none focus:ring-2 ${passwordError ? "border-red-500 focus:ring-red-500" : "border-gray-300 focus:ring-blue-500"
                  }`}
              />
              <button
                type="button"
                className="absolute inset-y-0 top-2 right-3 flex items-center text-gray-600 hover:text-gray-900 focus:outline-none"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <FaEyeSlash className="w-5 h-5" /> : <FaEye className="w-5 h-5" />}
              </button>
            </div>
            {passwordError && (
              <p className="text-sm text-red-500 mt-1">
                Password must be 8-18 characters, contain at least one uppercase letter, one number, and one special character.
              </p>
            )}
          </div>


          {/* Forgot Password */}
          <div className="flex justify-between items-center">
            <Link to="/forgotpassword" className="text-sm text-blue-600 hover:text-blue-800">
              Forgot Password?
            </Link>
          </div>
          <button
            type="submit"
            className={`w-full py-3 rounded-lg transition duration-300 ${loading || emailError || passwordError || !email || !password
              ? "bg-gray-400 cursor-not-allowed"
              : "bg-blue-600 text-white hover:bg-blue-700"
              }`}
            disabled={loading || emailError || passwordError || !email || !password}
          >
            {loading ? "Logging in..." : "Log In"}
          </button>

        </form>

        {/* Sign Up Link */}
        <div className="mt-6 text-center">
          <span className="text-sm text-gray-600">Don't have an account?</span>
          <Link to="/register" className="text-sm text-blue-600 hover:text-blue-800">
            {" "}
            Sign Up
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
