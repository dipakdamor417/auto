import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Navbar from './Navbar';
import Home from './Routes/Home';
import Footer from './Footer';
const Main = () => {
    return (
        <>
            <Navbar />
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="*" element={<div>404 - Page Not Found</div>} />
            </Routes>
            <Footer />
        </>
    );
};

export default Main;
