import React from "react";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <main className="flex flex-col items-center justify-center h-screen bg-gray-100 text-gray-800">
      <h2 className="text-3xl font-semibold mb-6">Welcome to the Home Page</h2>
      <div className="space-y-4 text-center">
        <p className="text-lg">Explore our platform and learn more about what we offer.</p>
        <div className="flex space-x-4 justify-center">
          <Link 
            to="/"
            className="bg-blue-500 text-white py-2 px-6 rounded hover:bg-blue-600"
          >
            Contact Us
          </Link>
          <Link
            to="/"
            className="bg-blue-500 text-white py-2 px-6 rounded hover:bg-blue-600"
          >
            Learn More
          </Link>
        </div>
      </div>
    </main>
  );
};

export default Home;
