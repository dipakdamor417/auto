import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FaHome, FaUsers, FaEnvelope, FaHistory, FaFileAlt } from 'react-icons/fa';

const Sidebar = ({ toggleSidebar }) => {
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const location = useLocation(); // Get current route

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="flex flex-col bg-gray-800 text-white w-full md:w-64 p-4">
      <nav className="flex flex-col mt-8 space-y-4">
        <Link
          to="/dashboard/"
          onClick={isMobile ? toggleSidebar : undefined}
          className={`flex items-center p-2 rounded ${
            location.pathname === '/dashboard' ? 'bg-blue-600' : 'hover:bg-blue-600'
          }`}
        >
          <FaHome className="mr-2" /> Home
        </Link>
        <Link
          to="/dashboard/employee"
          onClick={isMobile ? toggleSidebar : undefined}
          className={`flex items-center p-2 rounded ${
            location.pathname === '/dashboard/employee' ? 'bg-blue-600' : 'hover:bg-blue-600'
          }`}
        >
          <FaUsers className="mr-2" /> Employee Manage
        </Link>
        <Link
          to="/dashboard/emailconfig"
          onClick={isMobile ? toggleSidebar : undefined}
          className={`flex items-center p-2 rounded ${
            location.pathname === '/dashboard/emailconfig' ? 'bg-blue-600' : 'hover:bg-blue-600'
          }`}
        >
          <FaEnvelope className="mr-2" /> Email Config
        </Link>
        <Link
          to="/dashboard/emailhistory"
          onClick={isMobile ? toggleSidebar : undefined}
          className={`flex items-center p-2 rounded ${
            location.pathname === '/dashboard/emailhistory' ? 'bg-blue-600' : 'hover:bg-blue-600'
          }`}
        >
          <FaHistory className="mr-2" /> Email History
        </Link>
        <Link
          to="/dashboard/mailtemplate"
          onClick={isMobile ? toggleSidebar : undefined}
          className={`flex items-center p-2 rounded ${
            location.pathname === '/dashboard/mailtemplate' ? 'bg-blue-600' : 'hover:bg-blue-600'
          }`}
        >
          <FaFileAlt className="mr-2" /> Mail Template
        </Link>
      </nav>
    </div>
  );
};

export default Sidebar;
