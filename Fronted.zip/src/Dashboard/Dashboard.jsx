import React, { useState, useEffect } from 'react';
import { Route, Routes } from 'react-router-dom';
import { ImCross } from "react-icons/im";
import Topnav from './Topnav';
import Sidebar from './Sidebar';
import EmailHistory from './Pages/EmailHistory';
import EmailConfig from './Pages/EmailConfig';
import EmployeeDetails from './Pages/EmployeeDetails';
import TemplateCustom from './Pages/TemplateCustom';
import DashbaordPage from './Pages/DashbaordPage';

const Dashboard = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth > 845);
  const [isTabletView, setIsTabletView] = useState(window.innerWidth <= 845);

  // Toggle sidebar open/close
  const toggleSidebar = () => {
    setIsSidebarOpen((prev) => !prev);
  };

  // Handle responsive sidebar state
  useEffect(() => {
    const handleResize = () => {
      const isTablet = window.innerWidth <= 845;
      setIsTabletView(isTablet);

      if (!isTablet) {
        setIsSidebarOpen(true); // Default open on larger screens
      } else {
        setIsSidebarOpen(false); // Collapse on smaller screens
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="h-screen flex flex-col">
      <Topnav toggleSidebar={toggleSidebar} />

      <div className="flex flex-1 relative">
        {/* Sidebar */}
        <div
          className={`bg-gray-800 transition-all duration-300 ease-in-out ${
            isTabletView
              ? `fixed inset-y-0 left-0 z-50 w-64 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`
              : `h-full ${isSidebarOpen ? 'w-64' : 'w-0'} overflow-hidden`
          }`}
        >
          {isTabletView && (
            <button
              className="absolute top-2 right-2 text-white p-2"
              onClick={toggleSidebar}
            >
             <ImCross className="w-5 h-5" />
            </button>
          )}
          <Sidebar toggleSidebar={toggleSidebar} />
        </div>

        {/* Overlay for smaller screens */}
        {isTabletView && isSidebarOpen && (
          <div
            className="fixed inset-0 bg-black bg-opacity-50 z-40"
            onClick={toggleSidebar}
          ></div>
        )}

        {/* Main Content */}
        <div
          className={`flex-1 p-4 transition-all duration-300 ease-in-out`}
          style={{ width: isTabletView ? '100%' : isSidebarOpen ? 'calc(100% - 16rem)' : '100%' }}
        >
          <Routes>
            <Route path="/" element={<DashbaordPage />} />
            <Route path="/employee" element={<EmployeeDetails />} />
            <Route path="/emailconfig" element={<EmailConfig />} />
            <Route path="/emailhistory" element={<EmailHistory />} />
            <Route path="/mailtemplate" element={<TemplateCustom />} />
          </Routes>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
