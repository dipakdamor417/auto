import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { Table, Button, TextInput, Select, Tooltip } from '@mantine/core';
import { usePagination } from '@mantine/hooks';

const EmailHistory = () => {
    const [mailHistory, setMailHistory] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [sortBy, setSortBy] = useState('');
    const [filterStatus, setFilterStatus] = useState('');

    const runBirthdayScheduler = async () => {
        try {
            const response = await axios.post('http://localhost:8080/api/scheduler/manual');
            if (response.status === 200) {
                toast.success("Scheduler started successfully!");
                fetchMailHistory();
            }
            console.log(response.data, "Scheduler");
        } catch (error) {
            console.error("Error fetching mail history:", error);
        }
    };

    const clearFilters = () => {
        setSearchTerm('');
        setSortBy('');
        setFilterStatus('');
    };

    const fetchMailHistory = async () => {
        try {
            const response = await axios.get('http://localhost:8080/api/scheduler');
            setMailHistory(response.data);
            console.log(response.data, "Mail History");
        } catch (error) {
            toast.error(error.response?.data.message || "Error occurred");
            console.error("Error fetching mail history:", error);
        }
    };

    useEffect(() => {
        fetchMailHistory();
    }, []);

    const filteredData = mailHistory
        .filter(entry =>
            entry.DisplayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            entry.UserEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
            entry.EmpID.toString().includes(searchTerm)
        )
        .filter(entry => {
            if (filterStatus === 'Success') return entry.EmailStatus === true;
            if (filterStatus === 'Error') return entry.EmailStatus === false;
            return true;
        })
        .sort((a, b) => {
            if (sortBy === 'date') return new Date(a.SentTimestamp) - new Date(b.SentTimestamp);
            if (sortBy === 'name') return a.DisplayName.localeCompare(b.DisplayName);
            return 0;
        });

    // Pagination setup
    const totalPages = Math.ceil(filteredData.length / 20);
    const { range, setPage, active } = usePagination({ total: totalPages, initialPage: 1 });

    const paginatedData = filteredData.slice((active - 1) * 20, active * 20);

    return (
        <>
            <div className="flex justify-between items-center mb-6 max-w-6xl mx-auto p-4 font-Adani">
                <Button variant="filled" color="blue" onClick={runBirthdayScheduler} className="font-Adani">
                    Run Birthday Script
                </Button>
                <Button variant="outline" color="gray" onClick={clearFilters} className="font-Adani">
                    Clear Filters
                </Button>
            </div>

            <div className="max-w-6xl mx-auto p-4 font-Adani">

                <div className="bg-white shadow-md rounded-lg p-4">
                    {/* Search, Sort, and Filter */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-4">
                        <TextInput
                            placeholder="Search by name or email"
                            value={searchTerm}
                            onChange={(event) => setSearchTerm(event.currentTarget.value)}
                            classNames={{ input: 'font-Adani' }}
                        />
                        <Select
                            classNames={{ input: 'font-Adani' }}
                            placeholder="Sort by"
                            data={[
                                { value: 'date', label: 'Date', className: 'font-Adani p-2 cursor-pointer hover:bg-gray-200' },
                                { value: 'name', label: 'Name', className: 'font-Adani p-2 cursor-pointer hover:bg-gray-200' },
                            ]}
                            value={sortBy}
                            onChange={setSortBy}
                            className="w-full font-Adani"
                        />
                        <Select
                            placeholder="Filter by status"
                            data={[
                                { value: 'Success', label: 'Success', className: 'font-Adani p-2 cursor-pointer hover:bg-gray-200' },
                                { value: 'Error', label: 'Error', className: 'font-Adani p-2 cursor-pointer hover:bg-gray-200' },
                            ]}
                            value={filterStatus}
                            onChange={setFilterStatus}
                            className="w-full font-Adani"
                            classNames={{ input: 'font-Adani' }}
                        />
                    </div>

                    {/* Table */}
                    <div className="overflow-x-auto">
                        <Table className="min-w-full divide-y divide-gray-200 font-Adani">
                            <thead className="bg-gray-100">
                                <tr>
                                    <th className="px-4 py-2 text-left text-sm font-semibold text-gray-600">Date</th>
                                    <th className="px-4 py-2 text-left text-sm font-semibold text-gray-600">Display Name</th>
                                    <th className="px-4 py-2 text-left text-sm font-semibold text-gray-600">User Email</th>
                                    <th className="px-4 py-2 text-left text-sm font-semibold text-gray-600">Status</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                                {paginatedData.map((entry, index) => (
                                    <tr key={index} className="hover:bg-gray-50">
                                        <td className="px-4 py-3">{new Date(entry.SentTimestamp).toLocaleDateString()}</td>
                                        <td className="px-4 py-3">{entry.DisplayName}</td>
                                        <td className="px-4 py-3">{entry.UserEmail}</td>
                                        <td className="px-4 py-3">
                                            <Tooltip label={entry.ErrorDetails || ''} withArrow>
                                                <Button color={entry.EmailStatus ? 'green' : 'red'} className='font-Adani'>
                                                    {entry.EmailStatus ? 'Success' : 'Error'}
                                                </Button>
                                            </Tooltip>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </Table>
                    </div>

                    {/* Pagination */}
                    <div className="flex justify-center mt-4 space-x-2">
                        {range.map((page) => (
                            <button
                                key={page}
                                onClick={() => setPage(page)}
                                className={`px-3 py-1 rounded-md border ${active === page ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
                            >
                                {page}
                            </button>
                        ))}
                    </div>
                </div>
            </div>
        </>
    );
};

export default EmailHistory;
