import React, { useEffect, useState } from 'react';
import 'dhtmlx-scheduler/codebase/dhtmlxscheduler.css';
import { scheduler } from 'dhtmlx-scheduler';
import axios from 'axios';

const EmployeeCalendar = () => {
    const [events, setEvents] = useState([]); // Store API data
    const [selectedEventId, setSelectedEventId] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                scheduler.plugins({ recurring: true });
                scheduler.config.repeat_date = "%m/%d/%Y";
                scheduler.init('scheduler_here', new Date(), "month");
                scheduler.clearAll();
                scheduler.config.readonly = true; // Make calendar read-only

                scheduler.attachEvent("onClick", (id, e) => {
                    console.log("Selected Event ID:", id); // ✅ Log clicked event ID
                    setSelectedEventId(id);
                    return false;
                });

                const res = await axios.get('http://localhost:8080/api/dashboard/calendar');
                if (res.status === 200) {
                    console.log("Fetched Events:", res.data); // ✅ Log fetched events
                    setEvents(res.data);
                    scheduler.parse(res.data, "json");
                }
            } catch (error) {
                console.error("Error fetching calendar data:", error);
            }
        };
        fetchData();
    }, []);

    const selectedId = Number(selectedEventId?.split("#")[0]); // Extract and convert ID
    const matchedEvent = events.find(event => event.id === selectedId);

    if (matchedEvent) {
        console.log("Start Date:", matchedEvent.start_date); // ✅ Log only start_date
    } else {
        console.log("No matching event found.");
    }

    return (
        <div className="w-full h-full p-4 font-adani">
            <div id="scheduler_here" className="dhx_cal_container" style={{ width: '100%', height: '600px' }}></div>

            {matchedEvent && (
                <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
                    <div className="bg-white p-6 rounded-lg shadow-lg w-96 relative z-50">
                        <h2 className="text-lg font-bold text-center">🎉 Happy Birthday 🎉</h2>
                        <p className="text-center mt-2">{matchedEvent.text}</p>
                        <p className="text-center text-sm text-gray-600">
                            DOB: {matchedEvent.start_date ? new Date(matchedEvent.start_date).toLocaleDateString() : "Unknown"}
                        </p>
                        <button
                            onClick={() => setSelectedEventId(null)}
                            className="mt-4 w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600"
                        >
                            Close
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default EmployeeCalendar;
