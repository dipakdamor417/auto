import React, { useState, useEffect } from "react";
import Select from "react-select";
import axios from "axios";

import { toast } from "react-toastify";

const ConfigForm = ({ closeModal, fetchData }) => {

    const [employees, setEmployees] = useState([]);
    const [formData, setFormData] = useState({
        category: null,
        CC: [],
        BCC: [],
    });
    const [errors, setErrors] = useState({});

    useEffect(() => {
        const fetchEmployees = async () => {
            try {
                const response = await axios.get('http://localhost:8080/api/employee/get-emp');
                console.log(response.data, "Employees");
                setEmployees(response.data.map(emp => ({
                    value: emp.UserEmail,
                    label: `${emp.UserEmail} (${emp.Name})`
                })));
            } catch (error) {
                toast.error("Error fetching Employee.");
                console.error("Error fetching employees:", error);
            }
        };

        fetchEmployees();
    }, []);

    useEffect(() => {
        const fetchConfig = async () => {
            if (!formData.category) {
                setFormData(prevFormData => ({
                    ...prevFormData,
                    CC: [],
                    BCC: []
                }));
                return;
            }

            try {
                const response = await axios.get(`http://localhost:8080/api/emailconfig/${formData.category.value}`);
                console.log(response.data[0].CC, "Config");

                if (response.data[0]) {
                    setFormData(prevFormData => {
                        console.log(prevFormData);
                        const updatedFormData = {
                            ...prevFormData,
                            CC: response.data[0].CC?.length > 0
                                ? response.data[0].CC.map(email => {
                                    console.log(email);
                                    return { value: email, label: email };
                                })
                                : [],
                            BCC: response.data[0].BCC?.length > 0
                                ? response.data[0].BCC.map(email => {
                                    console.log(email);
                                    return { value: email, label: email };
                                })
                                : []
                        };
                        console.log(updatedFormData);
                        return updatedFormData;
                    });
                } else {
                    // Ensure empty CC and BCC when no data found
                    setFormData(prevFormData => ({
                        ...prevFormData,
                        CC: [],
                        BCC: []
                    }));
                }
            } catch (error) {
                console.error("Error fetching config:", error);
                setFormData(prevFormData => ({
                    ...prevFormData,
                    CC: [],
                    BCC: []
                }));
            }
        }

        fetchConfig();
    }, [formData.category]);

    const categoryOptions = [
        { value: 'Senior', label: 'Senior' },
        { value: 'Junior', label: 'Junior' }
    ];

    const emailOptions = employees;

    const validateForm = () => {
        const newErrors = {};
        if (!formData.category) newErrors.category = "Category is required";
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };


    const addEmailConfig = async () => {
        if (!validateForm()) return;

        try {
            console.log(formData);
            const response = await axios.post('http://localhost:8080/api/emailconfig/add', { formData }, { withCredentials: true });
            if (response.status === 200) {
                toast.success(response.data.message || "Email Config added!");
                fetchData();
                closeModal();
            }
        } catch (error) {
            toast.error(error.response?.data.message || "Error occurred");
            console.error("Error adding email configuration:", error);
        }
    };


    const handleChange = (selectedOption, actionMeta) => {
        setFormData(prev => ({
            ...prev,
            [actionMeta.name]: selectedOption
        }));
    };

    return (
        <div className="p-4">
            <div className="mt-4">
                <label className="block text-gray-700">Category</label>
                <Select
                    name="category"
                    options={categoryOptions}
                    value={formData.category}
                    onChange={handleChange}
                    className="w-full p-2 border rounded mb-4"
                />
                {errors.category && <p className="text-red-500">{errors.category}</p>}

                <label className="block text-gray-700">CC</label>
                <Select
                    name="CC"
                    options={emailOptions}
                    value={formData.CC}
                    onChange={handleChange}
                    isMulti
                    className="w-full p-2 border rounded mb-4"
                />
                {errors.CC && <p className="text-red-500">{errors.CC}</p>}

                <label className="block text-gray-700">BCC</label>
                <Select
                    name="BCC"
                    options={emailOptions}
                    value={formData.BCC}
                    onChange={handleChange}
                    isMulti
                    isDisabled={formData.category?.value === 'Junior'}
                    className="w-full p-2 border rounded mb-2"
                />
                {formData.category?.value === 'Junior' && (
                    <p className="text-sm text-yellow-600 mb-2">
                        As per policy, BCC will not receive emails for Junior category. Contact admin.
                    </p>
                )}
                {errors.BCC && <p className="text-red-500">{errors.BCC}</p>}


                <div className="flex space-x-4">
                    <button onClick={addEmailConfig} className="bg-blue-500 text-white px-4 py-2 rounded">Add Email Config</button>
                    <button onClick={() => closeModal()} className="bg-gray-500 text-white px-4 py-2 rounded">Cancel</button>
                </div>
            </div>
        </div>
    );
};

export default ConfigForm;