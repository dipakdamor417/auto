import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Table, Button, TextInput, Select, Tooltip } from '@mantine/core';
import { usePagination } from '@mantine/hooks';

const MailHistoryTable = () => {
  const [mailHistory, setMailHistory] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  useEffect(() => {
    const fetchMailHistory = async () => {
      try {
        const response = await axios.get('http://localhost:8080/api/scheduler');
        setMailHistory(response.data);
        console.log(response.data, "Scheduler");
      } catch (error) {
        console.error("Error fetching mail history:", error);
      }
    };
    fetchMailHistory();
  }, []);

  // Filter and sort data
  const filteredData = mailHistory
    .filter(entry =>
      entry.DisplayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.UserEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.EmpID.toString().includes(searchTerm)
    )
    .filter(entry => {
      if (filterStatus === 'Success') return entry.EmailStatus === true;
      if (filterStatus === 'Error') return entry.EmailStatus === false;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'name') return a.DisplayName.localeCompare(b.DisplayName);
      return new Date(b.SentTimestamp) - new Date(a.SentTimestamp); // default sort by latest date
    });

  // Pagination
  const itemsPerPage = 10;
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const { range, setPage, active } = usePagination({ total: totalPages, initialPage: 1 });
  const paginatedData = filteredData.slice((active - 1) * itemsPerPage, active * itemsPerPage);

  return (
    <div className="min-w-screen-lg max-w-screen-lg mx-auto p-4 font-Adani">
      <div className="bg-white shadow-md rounded-lg p-4">
        {/* Search, Sort, Filter, Clear */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <TextInput
            placeholder="Search by name or email"
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.currentTarget.value)}
            classNames={{ input: 'font-Adani' }}
          />
          <Select
            placeholder="Sort by"
            value={sortBy}
            onChange={setSortBy}
            data={[
              { value: 'date', label: 'Date' },
              { value: 'name', label: 'Name' },
            ]}
            classNames={{ input: 'font-Adani' }}
          />
          <Select
            placeholder="Filter by status"
            value={filterStatus}
            onChange={setFilterStatus}
            data={[
              { value: 'Success', label: 'Success' },
              { value: 'Error', label: 'Error' },
            ]}
            classNames={{ input: 'font-Adani' }}
          />
          <Button
            variant="outline"
            color="gray"
            className="font-Adani"
            onClick={() => {
              setSearchTerm('');
              setSortBy('');
              setFilterStatus('');
            }}
          >
            Clear Filters
          </Button>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <Table className="min-w-full divide-y divide-gray-200 font-Adani">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-4 py-2 text-left text-sm font-semibold text-gray-600">Date</th>
                <th className="px-4 py-2 text-left text-sm font-semibold text-gray-600">Display Name</th>
                <th className="px-4 py-2 text-left text-sm font-semibold text-gray-600">User Email</th>
                <th className="px-4 py-2 text-left text-sm font-semibold text-gray-600">Status</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {paginatedData.map((entry, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-4 py-3">{new Date(entry.SentTimestamp).toLocaleDateString()}</td>
                  <td className="px-4 py-3">{entry.DisplayName}</td>
                  <td className="px-4 py-3">{entry.UserEmail}</td>
                  <td className="px-4 py-3">
                    <Tooltip label={entry.ErrorDetails || ''} withArrow>
                      <Button color={entry.EmailStatus ? 'green' : 'red'} className="font-Adani">
                        {entry.EmailStatus ? 'Success' : 'Error'}
                      </Button>
                    </Tooltip>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>

        {/* Pagination */}
        <div className="flex justify-center mt-4 space-x-2">
          {range.map((page) => (
            <button
              key={page}
              onClick={() => setPage(page)}
              className={`px-3 py-1 rounded-md border ${
                active === page ? 'bg-blue-600 text-white' : 'bg-gray-200'
              }`}
            >
              {page}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MailHistoryTable;
