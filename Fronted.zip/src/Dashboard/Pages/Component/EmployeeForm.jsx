import React, { useState, useEffect } from "react";
import Select from "react-select";
import axios from "axios";
import { toast } from "react-toastify";
import { FaInfoCircle } from "react-icons/fa";
import { Tooltip } from '@mantine/core';

const EmployeeForm = ({ closeModal }) => {
    const [activeTab, setActiveTab] = useState("add");
    const [employees, setEmployees] = useState([]);
    const [selectedEmployee, setSelectedEmployee] = useState(null);
    const [formErrors, setFormErrors] = useState({});
    const [isFormValid, setIsFormValid] = useState(false);

    const [formData, setFormData] = useState({
        EmpID: "",
        Name: "",
        DisplayName: "",
        UserEmail: "",
        DOB: "",
        ManagerEmail: "",
        HODEmail: "",
        IsSenior: false,
        IsLeader: false,
        IsHOD: false,
    });

    const allowedDomains = ['adani.com', 'gmail.com'];


    const isValidDomainEmail = (email) => {
        const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!pattern.test(email)) return false;
        const domain = email.split('@')[1];
        console.log('Domain:', domain);
        console.log('Allowed Domains:', allowedDomains);
        return allowedDomains.includes(domain);
    };

    console.log(isValidDomainEmail('dipakkumar.damor@adani.com'));


    const validateForm = () => {
        const errors = {};
        if (!formData.EmpID || isNaN(formData.EmpID)) {
            errors.EmpID = "Employee ID must be a number.";
        }

        if (!formData.Name) errors.Name = "Name is required.";
        if (!formData.DisplayName) errors.DisplayName = "Display Name is required.";

        ["UserEmail", "ManagerEmail", "HODEmail"].forEach(field => {
            if (!formData[field]) {
                errors[field] = `${field} is required.`;
            } else if (!isValidDomainEmail(formData[field])) {
                errors[field] = "Invalid email or domain.";
            }
        });

        if (!formData.DOB) {
            errors.DOB = "DOB is required.";
        } else {
            const dobDate = new Date(formData.DOB);
            const nineteenYearsAgo = new Date();
            nineteenYearsAgo.setFullYear(nineteenYearsAgo.getFullYear() - 19);
            if (dobDate > nineteenYearsAgo) {
                errors.DOB = "Employee must be at least 19 years old.";
            }
        }

        setFormErrors(errors);
        return Object.keys(errors).length === 0;
    };

    useEffect(() => {
        const fetchEmployees = async () => {
            try {
                const response = await axios.get('http://localhost:8080/api/employee/get-emp');
                setEmployees(response.data.map(emp => ({
                    value: emp.EmpID,
                    label: `${emp.EmpID} (${emp.Name})`
                })));
            } catch (error) {
                console.error("Error fetching employees:", error);
            }
        };
        fetchEmployees();
    }, []);

    useEffect(() => {
        if (selectedEmployee && activeTab !== "add") {
            axios.get(`http://localhost:8080/api/employee/${selectedEmployee.value}`)
                .then(response => {
                    if (response.status === 200 && response.data) {
                        const employeeData = response.data;
                        if (employeeData.DOB) {
                            const [day, month, year] = employeeData.DOB.split("/");
                            employeeData.DOB = `${year}-${month}-${day}`;
                        }
                        setFormData(prev => ({ ...prev, ...employeeData }));
                    }
                })
                .catch(error => console.error("Error fetching employee data:", error));
        }
    }, [selectedEmployee, activeTab]);

    useEffect(() => {
        setIsFormValid(validateForm());
    }, [formData]);

    const handleChange = (e) => {
        const { name, value } = e.target;

        let val = value;
        if (name === "EmpID") {
            val = value.replace(/\D/g, ""); // Remove non-numeric
        }

        setFormData(prev => ({ ...prev, [name]: val }));
    };

    const handleSubmit = async (action) => {
        const isValid = validateForm();
        if ((action === "add" || action === "update") && !isValid) {
            toast.error("Please fix the highlighted errors.");
            return;
        }

        try {
            let response;
            if (action === "add") {
                response = await axios.post("http://localhost:8080/api/employee/add-emp-form", formData);
                toast.success(response.data.message || "Employee Added.");
            } else if (action === "update") {
                response = await axios.put("http://localhost:8080/api/employee/update-emp", formData);
                toast.success(response.data.message || "Employee Updated.");
            } else if (action === "delete") {
                response = await axios.delete(`http://localhost:8080/api/employee/delete-emp/${selectedEmployee.value}`);
                toast.success(response.data.message || "Employee Deleted.");
            }
            closeModal();
        } catch (error) {
            toast.error(error.response?.data.message || "Error occurred");
            console.error(error);
        }
    };

    const tooltipLabels = {
        IsSenior: "Employee who is GM and Above.",
        IsLeader: "Employee who is CEO and Above.",
        IsHOD: "Employee who are Head of the Particular Department."
    };

    const getMaxDOB = () => {
        const date = new Date();
        date.setFullYear(date.getFullYear() - 19);
        return date.toISOString().split("T")[0];
    };

    const renderInput = (field, type = "text") => (
        <div className="mb-4 max-w-md">
            <label className="block text-gray-700">{field} <span className="text-red-500">*</span></label>
            <input
                type={type}
                name={field}
                value={formData[field]}
                max={field === "DOB" ? getMaxDOB() : undefined}
                onChange={handleChange}
                className={`w-full p-2 border rounded ${formErrors[field] ? 'border-red-500' : 'border-gray-300'}`}
                disabled={activeTab === "delete"}
            />
            {formErrors[field] && <p className="text-red-500 text-sm">{formErrors[field]}</p>}
        </div>
    );

    return (
        <div className="p-4">
            <div className="flex border-b">
                {["add", "update", "delete"].map(tab => (
                    <button
                        key={tab}
                        className={`py-2 px-4 ${activeTab === tab ? "border-b-2 border-blue-500 text-blue-500" : "text-gray-600"}`}
                        onClick={() => {
                            setActiveTab(tab);
                            setSelectedEmployee(null);
                            setFormData({
                                EmpID: "",
                                Name: "",
                                DisplayName: "",
                                UserEmail: "",
                                DOB: "",
                                ManagerEmail: "",
                                HODEmail: "",
                                IsSenior: false,
                                IsLeader: false,
                                IsHOD: false,
                            });
                            setFormErrors({});
                        }}
                    >
                        {tab.charAt(0).toUpperCase() + tab.slice(1)}
                    </button>
                ))}
            </div>

            <div className="mt-4">
                {(activeTab === "update" || activeTab === "delete") && (
                    <div className="mb-4 max-w-md">
                        <label className="block text-gray-700">Select Employee</label>
                        <Select
                            options={employees}
                            value={selectedEmployee}
                            onChange={setSelectedEmployee}
                        />
                    </div>
                )}

                {activeTab !== "delete" && (
                    <>
                        {activeTab !== "update" && renderInput("EmpID")}
                        {renderInput("Name")}
                        {renderInput("DisplayName")}
                        {renderInput("UserEmail")}
                        {renderInput("DOB", "date")}
                        {renderInput("ManagerEmail")}
                        {renderInput("HODEmail")}
                    </>
                )}

                {["IsSenior", "IsLeader", "IsHOD"].map(field => (
                    <div key={field} className="mb-4 flex flex-col sm:flex-row sm:items-center sm:space-x-4 max-w-md">
                        <label className="flex items-center space-x-2 text-gray-700">
                            <span>{field.replace("Is", "")}</span>
                            <Tooltip label={tooltipLabels[field]} withArrow>
                                <FaInfoCircle className="text-blue-500 cursor-pointer" />
                            </Tooltip>
                        </label>
                        <div className="flex space-x-4">
                            <label className="flex items-center space-x-2">
                                <input
                                    type="radio"
                                    name={field}
                                    value="true"
                                    checked={formData[field] === true}
                                    onChange={() => setFormData(prev => ({ ...prev, [field]: true }))}
                                />
                                <span>Yes</span>
                            </label>
                            <label className="flex items-center space-x-2">
                                <input
                                    type="radio"
                                    name={field}
                                    value="false"
                                    checked={formData[field] === false}
                                    onChange={() => setFormData(prev => ({ ...prev, [field]: false }))}
                                />
                                <span>No</span>
                            </label>
                        </div>
                    </div>
                ))}

                <div className="flex space-x-4 mt-6 max-w-md">
                    {activeTab === "add" && (
                        <button
                            onClick={() => handleSubmit("add")}
                            className={`px-4 py-2 rounded ${isFormValid ? "bg-blue-500 text-white" : "bg-blue-300 text-white cursor-not-allowed"}`}
                            disabled={!isFormValid}
                        >
                            Add Employee
                        </button>
                    )}
                    {activeTab === "update" && (
                        <button
                            onClick={() => handleSubmit("update")}
                            className={`px-4 py-2 rounded ${isFormValid ? "bg-yellow-500 text-white" : "bg-yellow-300 text-white cursor-not-allowed"}`}
                            disabled={!isFormValid}
                        >
                            Update Employee
                        </button>
                    )}
                    {activeTab === "delete" && (
                        <button onClick={() => handleSubmit("delete")} className="bg-red-500 text-white px-4 py-2 rounded">
                            Delete Employee
                        </button>
                    )}
                    <button onClick={closeModal} className="bg-gray-500 text-white px-4 py-2 rounded">Cancel</button>
                </div>
            </div>
        </div>
    );
};

export default EmployeeForm;
