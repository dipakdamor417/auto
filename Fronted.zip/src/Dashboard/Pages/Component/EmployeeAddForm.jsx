import React, { useState, useEffect } from "react";
import Select from "react-select";
import axios from "axios";
import { toast } from "react-toastify";
import { FaInfoCircle } from "react-icons/fa";
import { Tooltip } from "@mantine/core";

const EmployeeAddForm = ({ fetchEmployee, onClose }) => {
    const [formData, setFormData] = useState({
        EmpID: "",
        Name: "",
        UserEmail: "",
        DisplayName: "",
        DOB: "",
        ManagerEmail: "",
        HODEmail: "",
        IsSenior: false,
        IsLeader: false,
        IsHOD: false,
    });

    const [managers, setManagers] = useState([]);
    const [hods, setHODs] = useState([]);
    const [touched, setTouched] = useState({});

    const tooltipLabels = {
        IsSenior: "Employee who is GM and Above.",
        IsLeader: "Employee who is CEO and Above.",
        IsHOD: "Employee who is Head of the Particular Department."
    };

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:8080/api/employee/get-emp');
                const options = response.data.map(emp => ({
                    value: emp.UserEmail,
                    label: `${emp.EmpID} (${emp.Name})`
                }));
                setManagers(options);
                setHODs(options);
            } catch (error) {
                toast.error("Error fetching data");
            }
        };
        fetchData();
    }, []);

    const isFormValid = () => {
        return (
            formData.EmpID &&
            formData.Name &&
            formData.UserEmail &&
            formData.DisplayName &&
            formData.DOB &&
            formData.ManagerEmail &&
            formData.HODEmail
        );
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
        setTouched({ ...touched, [name]: true });
    };

    const handleSelectChange = (name, selectedOption) => {
        setFormData({ ...formData, [name]: selectedOption?.value || "" });
        setTouched({ ...touched, [name]: true });
    };

    const isValidDomainEmail = (email) => {
        const allowedDomains = ['adani.com', 'gmail.com'];
        const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!pattern.test(email)) return false;
        const domain = email.split('@')[1];
        return allowedDomains.includes(domain);
    };


    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!isFormValid()) {
            toast.error("Please fill in all required fields.");
            return;
        }
        const { UserEmail, ManagerEmail, HODEmail } = formData;
        for (const [label, email] of [["User", UserEmail], ["Manager", ManagerEmail], ["HOD", HODEmail]]) {
            if (!isValidDomainEmail(email)) return toast.error(`${label} email must be from adani.com or gmail.com`);
        }

        try {
            const res = await axios.post("http://localhost:8080/api/employee/add-emp-form", formData, {
                withCredentials: true,
            });
            if (res.status === 200) {
                toast.success("Employee added successfully!");
                setFormData({
                    EmpID: "",
                    Name: "",
                    UserEmail: "",
                    DisplayName: "",
                    DOB: "",
                    ManagerEmail: "",
                    HODEmail: "",
                    IsSenior: false,
                    IsLeader: false,
                    IsHOD: false,
                });
                fetchEmployee();
                onClose();
            }
        } catch (error) {
            toast.error(error.response?.data.message || "Error adding Employee");
        }
    };

    const getInputClass = (field) => {
        return `w-full px-3 py-2 border rounded-md focus:ring focus:ring-blue-300 ${touched[field] && !formData[field] ? "border-red-500" : ""
            }`;
    };

    const getMaxDOB = () => {
        const today = new Date();
        today.setFullYear(today.getFullYear() - 18);
        return today.toISOString().split("T")[0];
    };

    return (
        <form onSubmit={handleSubmit} className="max-w-2xl mx-auto p-6 bg-white rounded-lg space-y-4">
            {/* Emp ID */}
            <div>
                <label className="block font-medium text-gray-700">Employee ID</label>
                <input
                    type="number"
                    name="EmpID"
                    value={formData.EmpID}
                    onChange={handleChange}
                    className={getInputClass("EmpID")}
                    required
                />
            </div>

            {/* Name */}
            <div>
                <label className="block font-medium text-gray-700">Name</label>
                <input
                    type="text"
                    name="Name"
                    value={formData.Name}
                    onChange={handleChange}
                    className={getInputClass("Name")}
                    required
                />
            </div>

            {/* Email */}
            <div>
                <label className="block font-medium text-gray-700">Email</label>
                <input
                    type="email"
                    name="UserEmail"
                    value={formData.UserEmail}
                    onChange={handleChange}
                    className={getInputClass("UserEmail")}
                    required
                />
            </div>

            {/* Display Name */}
            <div>
                <label className="block font-medium text-gray-700">Display Name</label>
                <input
                    type="text"
                    name="DisplayName"
                    value={formData.DisplayName}
                    onChange={handleChange}
                    className={getInputClass("DisplayName")}
                    required
                />
            </div>

            {/* DOB */}
            <div>
                <label className="block font-medium text-gray-700">Date of Birth</label>
                <input
                    type="date"
                    name="DOB"
                    value={formData.DOB}
                    onChange={handleChange}
                    max={getMaxDOB()}
                    className={getInputClass("DOB")}
                    required
                />
            </div>

            {/* Manager Email */}
            <div>
                <label className="block font-medium text-gray-700">Manager</label>
                <Select
                    options={managers}
                    onChange={(selected) => handleSelectChange("ManagerEmail", selected)}
                    className={`${touched.ManagerEmail && !formData.ManagerEmail ? "border border-red-500 rounded-md" : ""}`}
                    placeholder="Select Manager"
                    isClearable
                />
            </div>

            {/* HOD Email */}
            <div>
                <label className="block font-medium text-gray-700">HOD</label>
                <Select
                    options={hods}
                    onChange={(selected) => handleSelectChange("HODEmail", selected)}
                    className={`${touched.HODEmail && !formData.HODEmail ? "border border-red-500 rounded-md" : ""}`}
                    placeholder="Select HOD"
                    isClearable
                />
            </div>

            {/* Roles with Tooltips */}
            {["IsSenior", "IsLeader", "IsHOD"].map((field) => (
                <div key={field} className="flex flex-col space-y-1">
                    <label className="flex items-center space-x-2 text-gray-700 font-medium">
                        <span>{field.replace("Is", "")}</span>
                        <Tooltip label={tooltipLabels[field]} withArrow>
                            <FaInfoCircle className="text-blue-500 cursor-pointer" />
                        </Tooltip>
                    </label>
                    <div className="flex space-x-4">
                        <label className="flex items-center space-x-1">
                            <input
                                type="radio"
                                name={field}
                                value="true"
                                checked={formData[field] === true}
                                onChange={() => setFormData({ ...formData, [field]: true })}
                                className="accent-blue-500"
                            />
                            <span>Yes</span>
                        </label>
                        <label className="flex items-center space-x-1">
                            <input
                                type="radio"
                                name={field}
                                value="false"
                                checked={formData[field] === false}
                                onChange={() => setFormData({ ...formData, [field]: false })}
                                className="accent-blue-500"
                            />
                            <span>No</span>
                        </label>
                    </div>
                </div>
            ))}

            {/* Buttons */}
            <div className="flex justify-end space-x-2">
                <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                    disabled={!isFormValid()}
                >
                    Submit
                </button>
                <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 border rounded-md hover:bg-gray-100"
                >
                    Cancel
                </button>
            </div>
        </form>
    );
};

export default EmployeeAddForm;
