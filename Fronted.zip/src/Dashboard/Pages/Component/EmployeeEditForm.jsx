import React, { useState, useEffect } from "react";
import Select from "react-select";
import axios from "axios";
import { FaInfoCircle } from "react-icons/fa";
import { toast } from "react-toastify";
import { Tooltip } from "@mantine/core";

const EmployeeEditForm = ({ employeeData, onClose, fetchEmployee }) => {
    const [managers, setManagers] = useState([]);
    const [hods, setHODs] = useState([]);

    const [formData, setFormData] = useState({
        EmpID: '',
        Name: '',
        UserEmail: '',
        DisplayName: '',
        DOB: '',
        ManagerEmail: '',
        HODEmail: '',
        IsSenior: false,
        IsLeader: false,
        IsHOD: false,
    });

    const [errors, setErrors] = useState({});
    const [touched, setTouched] = useState({});
    const [isSubmitting, setIsSubmitting] = useState(false);

    const tooltipLabels = {
        IsSenior: "Employee who is GM and Above.",
        IsLeader: "Employee who is CEO and Above.",
        IsHOD: "Employee who are Head of the Particular Department.",
    };

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:8080/api/employee/get-emp');
                const options = response.data.map(emp => ({
                    value: emp.UserEmail,
                    label: `${emp.EmpID} (${emp.Name})`,
                }));
                setManagers(options);
                setHODs(options);
            } catch (error) {
                toast.error("Error fetching employee list");
            }
        };
        fetchData();
    }, []);

    useEffect(() => {
        if (employeeData) {
            const formattedDOB = employeeData.DOB ? new Date(employeeData.DOB).toISOString().split('T')[0] : '';
            setFormData({
                EmpID: employeeData.EmpID || '',
                Name: employeeData.Name || '',
                UserEmail: employeeData.UserEmail || '',
                DisplayName: employeeData.DisplayName || '',
                DOB: formattedDOB,
                ManagerEmail: employeeData.ManagerEmail || '',
                HODEmail: employeeData.HODEmail || '',
                IsSenior: employeeData.IsSenior || false,
                IsLeader: employeeData.IsLeader || false,
                IsHOD: employeeData.IsHOD || false,
            });
        }
    }, [employeeData]);

    const handleSelectChange = (field, selectedOption) => {
        const value = selectedOption ? selectedOption.value : '';
        setFormData(prev => ({ ...prev, [field]: value }));
        setTouched(prev => ({ ...prev, [field]: true }));
    };

    const validate = () => {
        const newErrors = {};
        if (!formData.EmpID || isNaN(formData.EmpID)) newErrors.EmpID = "Emp ID must be a number";
        if (!formData.Name.trim()) newErrors.Name = "Name is required";
        if (!formData.UserEmail.trim()) newErrors.UserEmail = "Email is required";
        if (!formData.DisplayName.trim()) newErrors.DisplayName = "Display Name is required";
        if (!formData.DOB) newErrors.DOB = "Date of Birth is required";
        if (!formData.ManagerEmail) newErrors.ManagerEmail = "Manager is required";
        if (!formData.HODEmail) newErrors.HODEmail = "HOD is required";
        return newErrors;
    };

    const isValidDomainEmail = (email) => {
        const allowedDomains = ['adani.com', 'gmail.com'];
        const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!pattern.test(email)) return false;
        const domain = email.split('@')[1];
        return allowedDomains.includes(domain);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const newErrors = validate();
        setErrors(newErrors);
        setTouched({
            EmpID: true,
            Name: true,
            UserEmail: true,
            DisplayName: true,
            DOB: true,
            ManagerEmail: true,
            HODEmail: true
        });

        if (Object.keys(newErrors).length > 0) return;

        const { UserEmail, ManagerEmail, HODEmail } = formData;
        for (const [label, email] of [["User", UserEmail], ["Manager", ManagerEmail], ["HOD", HODEmail]]) {
            if (!isValidDomainEmail(email)) return toast.error(`${label} email must be from adani.com or gmail.com`);
        }

        try {
            const response = await axios.put(
                `http://localhost:8080/api/employee/update-emp`,
                formData,
                { withCredentials: true }
            );
            if (response.status === 200) {
                toast.success(response.data.message || "Employee Updated!");
                fetchEmployee();
                onClose();
            }
        } catch (error) {
            toast.error(error.response?.data.message || "Error occurred");
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
        setTouched({ ...touched, [name]: true });
        if (errors[name]) setErrors({ ...errors, [name]: "" });
    };

    const today = new Date();
    const maxDOB = new Date(today.setFullYear(today.getFullYear() - 18)).toISOString().split('T')[0];

    return (
        <form onSubmit={handleSubmit} className="max-w-2xl mx-auto p-6 bg-white rounded-lg space-y-4">
            {/* Emp ID */}
            <div>
                <label className="block font-medium text-gray-700">Emp ID</label>
                <input
                    type="number"
                    name="EmpID"
                    value={formData.EmpID}
                    onChange={handleChange}
                    className={`w-full px-3 py-2 border rounded-md focus:ring focus:ring-blue-300 ${touched.EmpID && errors.EmpID ? 'border-red-500' : ''}`}
                />
            </div>

            {/* Name */}
            <div>
                <label className="block font-medium text-gray-700">Name</label>
                <input
                    type="text"
                    name="Name"
                    value={formData.Name}
                    onChange={handleChange}
                    className={`w-full px-3 py-2 border rounded-md focus:ring focus:ring-blue-300 ${touched.Name && errors.Name ? 'border-red-500' : ''}`}
                />
            </div>

            {/* Email */}
            <div>
                <label className="block font-medium text-gray-700">Email</label>
                <input
                    type="email"
                    name="UserEmail"
                    value={formData.UserEmail}
                    onChange={handleChange}
                    className={`w-full px-3 py-2 border rounded-md focus:ring focus:ring-blue-300 ${touched.UserEmail && errors.UserEmail ? 'border-red-500' : ''}`}
                />
            </div>

            {/* Display Name */}
            <div>
                <label className="block font-medium text-gray-700">Display Name</label>
                <input
                    type="text"
                    name="DisplayName"
                    value={formData.DisplayName}
                    onChange={handleChange}
                    className={`w-full px-3 py-2 border rounded-md focus:ring focus:ring-blue-300 ${touched.DisplayName && errors.DisplayName ? 'border-red-500' : ''}`}
                />
            </div>

            {/* DOB */}
            <div>
                <label className="block font-medium text-gray-700">Date of Birth</label>
                <input
                    type="date"
                    name="DOB"
                    value={formData.DOB}
                    onChange={handleChange}
                    max={maxDOB}
                    className={`w-full px-3 py-2 border rounded-md focus:ring focus:ring-blue-300 ${touched.DOB && errors.DOB ? 'border-red-500' : ''}`}
                />
            </div>

            {/* Manager Email */}
            <div>
                <label className="block font-medium text-gray-700">Manager</label>
                <Select
                    options={managers}
                    value={managers.find(opt => opt.value === formData.ManagerEmail) || null}
                    onChange={(selected) => handleSelectChange("ManagerEmail", selected)}
                    className={`react-select-container ${touched.ManagerEmail && errors.ManagerEmail ? 'border border-red-500 rounded-md' : ''}`}
                    placeholder="Select Manager"
                    isClearable
                />
            </div>

            {/* HOD Email */}
            <div>
                <label className="block font-medium text-gray-700">HOD</label>
                <Select
                    options={hods}
                    value={hods.find(opt => opt.value === formData.HODEmail) || null}
                    onChange={(selected) => handleSelectChange("HODEmail", selected)}
                    className={`react-select-container ${touched.HODEmail && errors.HODEmail ? 'border border-red-500 rounded-md' : ''}`}
                    placeholder="Select HOD"
                    isClearable
                />
            </div>

            {/* Radio Buttons with Tooltip */}
            {["IsSenior", "IsLeader", "IsHOD"].map((field) => (
                <div key={field} className="flex flex-col space-y-1">
                    <label className="flex items-center space-x-2 text-gray-700 font-medium">
                        <span>{field.replace("Is", "")}</span>
                        <Tooltip label={tooltipLabels[field]} withArrow>
                            <FaInfoCircle className="text-blue-500 cursor-pointer" />
                        </Tooltip>
                    </label>
                    <div className="flex space-x-4">
                        <label className="flex items-center space-x-1">
                            <input
                                type="radio"
                                name={field}
                                value="true"
                                checked={formData[field] === true}
                                onChange={() => setFormData({ ...formData, [field]: true })}
                                className="accent-blue-500"
                            />
                            <span>Yes</span>
                        </label>
                        <label className="flex items-center space-x-1">
                            <input
                                type="radio"
                                name={field}
                                value="false"
                                checked={formData[field] === false}
                                onChange={() => setFormData({ ...formData, [field]: false })}
                                className="accent-blue-500"
                            />
                            <span>No</span>
                        </label>
                    </div>
                </div>
            ))}

            {/* Buttons */}
            <div className="flex justify-end space-x-2">
                <button
                    type="submit"
                    className={`px-4 py-2 text-white rounded-md ${isSubmitting ? 'bg-gray-400' : 'bg-blue-600 hover:bg-blue-700'}`}
                    disabled={isSubmitting}
                >
                    Submit
                </button>
                <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 border rounded-md hover:bg-gray-100"
                >
                    Cancel
                </button>
            </div>
        </form>
    );
};

export default EmployeeEditForm;
