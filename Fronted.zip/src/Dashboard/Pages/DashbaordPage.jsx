import React, { useEffect, useState } from "react";
import { Table, Modal } from "@mantine/core";
import EmployeeCalendar from "./Component/EmployeeCalendar";
import axios from "axios";
import MailHistoryTable from "./Component/MailHistoryTable";
import EmployeeForm from "./Component/EmployeeForm";

const DashboardPage = () => {
  const [activeSection, setActiveSection] = useState(null);
  const [birthdayToday, setBirthdayToday] = useState([]);
  const [count, setCount] = useState(0);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const fetchBirthdays = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/dashboard/birthdayToday", { withCredentials: true });
        console.log(response.data);
        if (response.status === 200) {
          setCount(response.data.length);
          setBirthdayToday(response.data);
        }
      } catch (error) {
        console.error("Error fetching birthdays:", error);
      }
    };

    fetchBirthdays();
  }, []);

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  return (
    <div className="p-4 min-h-screen flex flex-col items-center">
      {/* Dashboard Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 w-full max-w-6xl">
        {[
          { label: `Employee Birthday Today ${count > 0 ? `(${count})` : ""}`, section: "birthday", bg: "bg-blue-500", hover: "hover:bg-blue-600" },
          { label: "Employee Birthday Calendar", section: "calendar", bg: "bg-green-500", hover: "hover:bg-green-600" },
          { label: "Email History", section: "emailHistory", bg: "bg-yellow-500", hover: "hover:bg-yellow-600" },
          { label: "Manage Employee", action: openModal, bg: "bg-red-500", hover: "hover:bg-red-600" }
        ].map(({ label, section, action, bg, hover }) => (
          <button
            key={label}
            className={`text-white border p-4 rounded-2xl shadow-lg transition w-full ${bg} ${hover}`}
            onClick={section ? () => setActiveSection(section) : action}
          >
            <h2 className="text-xl font-semibold text-center">{label}</h2>
          </button>
        ))}
      </div>

      {/* Content Section */}
      <div className="w-full max-w-6xl mt-3 p-4 rounded-lg min-h-[300px] flex  justify-center overflow-hidden">
        {activeSection === "birthday" && (
          <div className="overflow-x-auto w-full">
            <Table className="min-w-full divide-y divide-gray-200 font-Adani">
              <thead className="bg-gray-100">
                <tr>
                  <th className="px-4 py-2 text-left text-sm font-Adani font-semibold text-gray-600">Employee Id</th>
                  <th className="px-4 py-2 text-left text-sm font-Adani font-semibold text-gray-600">Employee Name</th>
                  <th className="px-4 py-2 text-left text-sm  font-Adani font-semibold text-gray-600">Birthday</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {birthdayToday.length > 0 ? (
                  birthdayToday.map((employee) => (
                    <tr key={employee.EmpID} className="hover:bg-gray-50">
                      <td className="px-4 py-3 font-Adani">{employee.EmpID}</td>
                      <td className="px-4 py-3 font-Adani">{employee.Name}</td>
                      <td className="px-4 py-3 font-Adani">
                        {new Date(employee.DOB).toLocaleDateString("en-GB", {
                          day: "2-digit",
                          month: "short",
                          year: "numeric",
                        })}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="3" className="px-4 py-3 text-center text-gray-500">No birthdays today</td>
                  </tr>
                )}
              </tbody>
            </Table>
          </div>
        )}
        {activeSection === "calendar" && <EmployeeCalendar />}
        {activeSection === "emailHistory" && (
          <div className="overflow-y-auto max-h-[500px]">
            <MailHistoryTable />
          </div>
        )}

      </div>

      {/* Employee Management Modal */}
      <Modal opened={isModalOpen} onClose={closeModal} title="Manage Employee"  centered>
        <EmployeeForm closeModal={closeModal} />
      </Modal>
    </div>
  );
};

export default DashboardPage;