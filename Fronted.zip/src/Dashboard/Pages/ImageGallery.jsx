import React from 'react';
import { RiDeleteBin7Fill } from 'react-icons/ri';

const ImageGallery = ({ images, handleDelete, handleCustomize }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {images.length > 0 ? images.map((img, i) => (
        <div key={i} className="border p-2 rounded">
          <img src={img.data} alt={img.filename} className="w-full h-40 object-cover" />
          <p className="text-center text-sm mt-2">{img.filename}</p>
          <div className='flex justify-between mt-2'>
            <button onClick={() => handleDelete(img)} className='text-red-600 flex items-center gap-1'>
              <RiDeleteBin7Fill /> Delete
            </button>
            <button onClick={() => handleCustomize(img)} className='bg-green-500 text-white px-2 py-1 rounded'>
              Customize
            </button>
          </div>
        </div>
      )) : <p>No images available.</p>}
    </div>
  );
};

export default ImageGallery;
