import React, { useRef, useState, useEffect } from 'react';
import { Stage, Layer, Image, Text } from 'react-konva';
import useImage from 'use-image';
import axios from 'axios';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const EditorComponent = ({ selectedImage }) => {
  const layerRef = useRef(null);
  const stageRef = useRef(null);
  const containerRef = useRef(null);

  const [loadedImageObject] = useImage(selectedImage?.data);
  const [texts, setTexts] = useState([]);
  const [stageScale, setStageScale] = useState(1);

  useEffect(() => {
    const fetchConfig = async () => {
      if (!selectedImage?.filename) return;

      try {
        const res = await axios.get(`http://localhost:8080/api/imagetemplate/image-config/get/${selectedImage.filename}`);
        if (res.data?.texts) {
          const updatedTexts = res.data.texts.map((t, index) => ({
            id: index.toString(),
            draggable: true,
            ...t,
          }));
          setTexts(updatedTexts);
        } else {
          setTexts([defaultText()]);
        }
      } catch (err) {
        console.warn('No existing config found:', err.message);
        setTexts([defaultText()]);
      }
    };

    fetchConfig();
  }, [selectedImage]);

  const defaultText = () => ({
    id: '1',
    text: 'Dear {{name}}',
    x: 50,
    y: 50,
    fontSize: 30,
    fontFamily: 'Arial',
    fill: 'white',
    draggable: true,
  });

  const handleDragEnd = (e, id) => {
    const updatedTexts = texts.map((t) =>
      t.id === id ? { ...t, x: e.target.x(), y: e.target.y() } : t
    );
    setTexts(updatedTexts);
  };

  const handleTextChange = (id, key, value) => {
    const updatedTexts = texts.map((t) =>
      t.id === id ? { ...t, [key]: value } : t
    );
    setTexts(updatedTexts);
  };

  const addText = () => {
    setTexts([
      ...texts,
      {
        id: Date.now().toString(),
        text: 'New Text',
        x: 100,
        y: 100,
        fontSize: 24,
        fontFamily: 'Arial',
        fill: 'white',
        draggable: true,
      },
    ]);
  };

  const deleteText = (id) => {
    setTexts(texts.filter(t => t.id !== id));
  };

  const sendToBackend = async () => {
    if (!selectedImage?.filename) return toast.error('No image selected!');

    const exportData = {
      backgroundImage: selectedImage.filename,
      texts: texts.map((t) => ({
        text: t.text,
        x: t.x,
        y: t.y,
        fontSize: Number(t.fontSize),
        fontFamily: t.fontFamily,
        fill: t.fill,
      })),
    };

    try {
      const response = await axios.post('http://localhost:8080/api/imagetemplate/image-config', exportData);
      toast.success('Customization saved successfully!');
      console.log('Response:', response.data);
    } catch (error) {
      console.error('Error sending customization:', error);
      toast.error('Failed to save customization.');
    }
  };

  useEffect(() => {
    if (!loadedImageObject || !containerRef.current) return;

    const containerWidth = containerRef.current.offsetWidth;
    const scale = containerWidth / loadedImageObject.width;
    setStageScale(scale);
  }, [loadedImageObject]);

  if (!loadedImageObject) return <div>Loading...</div>;

  const imageWidth = loadedImageObject.width;
  const imageHeight = loadedImageObject.height;
  const scaledHeight = imageHeight * stageScale;

  return (
    <div className="mt-10">
      <h2 className="text-lg font-semibold mb-4">Editor</h2>

      <div className="mb-4 flex flex-wrap gap-2">
        <button onClick={addText} className="bg-green-600 text-white px-3 py-1 rounded">Add Text</button>
        <button onClick={sendToBackend} className="bg-blue-600 text-white px-3 py-1 rounded">Save</button>
      </div>

      {texts.map((t) => (
        <div key={t.id} className="flex flex-wrap items-start gap-2 mb-2">
          <textarea
            value={t.text}
            onChange={(e) => handleTextChange(t.id, 'text', e.target.value)}
            className="border px-3 py-2 rounded resize-y w-full md:w-1/2 h-24"
            placeholder="Enter multiline text"
          />
          <select
            value={t.fontFamily}
            onChange={(e) => handleTextChange(t.id, 'fontFamily', e.target.value)}
            className="border px-2 py-1 rounded"
          >
            <option value="Arial">Arial</option>
            <option value="Times New Roman">Times New Roman</option>
            <option value="Courier New">Courier New</option>
            <option value="Comic Sans MS">Comic Sans MS</option>
            <option value="Adani Regular">Adani Regular</option>
            <option value="Baguet Script">Baguet Regular</option>
          </select>
          <input
            type="number"
            value={t.fontSize}
            onChange={(e) => {
              const value = Math.min(Number(e.target.value), 72);
              handleTextChange(t.id, 'fontSize', value);
            }}
            className="border px-2 py-1 rounded w-20"
            placeholder="Size"
          />

          <input
            type="color"
            value={t.fill}
            onChange={(e) => handleTextChange(t.id, 'fill', e.target.value)}
            className="w-10 h-10"
          />
          <button
            onClick={() => deleteText(t.id)}
            className="bg-red-500 text-white px-2 py-1 rounded"
          >
            Delete
          </button>
        </div>
      ))}

      <div
        ref={containerRef}
        className="overflow-auto border rounded-lg"
        style={{ maxHeight: '80vh' }}
      >
        <Stage
          width={imageWidth * stageScale}
          height={scaledHeight}
          scale={{ x: stageScale, y: stageScale }}
          ref={stageRef}
        >
          <Layer ref={layerRef}>
            <Image
              image={loadedImageObject}
              width={imageWidth}
              height={imageHeight}
              x={0}
              y={0}
            />
            {texts.map((t) => (
              <Text
                key={t.id}
                {...t}
                onDragEnd={(e) => handleDragEnd(e, t.id)}
              />
            ))}
          </Layer>
        </Stage>
      </div>
    </div>
  );
};

export default EditorComponent;
