import React, { useEffect, useState } from 'react';
import { Tabs, Table, Button, Modal } from '@mantine/core';
import ConfigForm from './Component/ConfigForm';
import axios from 'axios';

const EmailConfig = () => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [data, setData] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:8080/api/emailconfig');
                console.log(response.data);
                setData(response.data);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };
        fetchData();
    }, []);
    
    const fetchData = async () => {
        try {
            const response = await axios.get('http://localhost:8080/api/emailconfig');
            console.log(response.data);
            setData(response.data);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    const openModal = () => setIsModalOpen(true);
    const closeModal = () => setIsModalOpen(false);

    const filterDataByCategory = (category) => data.filter(item => item.category === category);

    const formatArray = (array) => array.join(', ');

    return (
        <div className="max-w-5xl mx-auto p-4 font-Adani">
            {/* Header */}
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold">📧 Email Configurations</h2>
                <Button variant="filled" color="blue" onClick={openModal} className="font-Adani">
                    + Add Email Config
                </Button>
            </div>

            {/* Tabs */}
            <Tabs defaultValue="Senior" variant="pills">
                <Tabs.List className="flex gap-4 bg-gray-100 p-2 rounded-lg">
                    <Tabs.Tab value="Senior" className="px-4 py-2 rounded-md font-Adani text-sm">Senior</Tabs.Tab>
                    <Tabs.Tab value="Junior" className="px-4 py-2 rounded-md font-Adani text-sm">Junior</Tabs.Tab>
                </Tabs.List>

                {/* Senior Tab */}
                <Tabs.Panel value="Senior" className="mt-4">
                    <div className="overflow-x-auto">
                        <Table highlightOnHover withBorder withColumnBorders className="font-Adani">
                            <thead className="bg-gray-100">
                                <tr>
                                    <th className="px-4 py-2 text-left">Category</th>
                                    <th className="px-4 py-2 text-left">CC</th>
                                    <th className="px-4 py-2 text-left">BCC</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filterDataByCategory('Senior').map((item) => (
                                    <tr key={item.id} className="hover:bg-gray-50">
                                        <td className="px-4 py-3">{item.category}</td>
                                        <td className="px-4 py-3">{formatArray(item.CC)}</td>
                                        <td className="px-4 py-3">{formatArray(item.BCC)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </Table>
                    </div>
                </Tabs.Panel>

                {/* Junior Tab */}
                <Tabs.Panel value="Junior" className="mt-4">
                    <div className="overflow-x-auto">
                        <Table highlightOnHover withBorder withColumnBorders className="font-Adani">
                            <thead className="bg-gray-100">
                                <tr>
                                    <th className="px-4 py-2 text-left">Category</th>
                                    <th className="px-4 py-2 text-left">CC</th>
                                    <th className="px-4 py-2 text-left">BCC</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filterDataByCategory('Junior').map((item) => (
                                    <tr key={item.id} className="hover:bg-gray-50">
                                        <td className="px-4 py-3">{item.category}</td>
                                        <td className="px-4 py-3">{formatArray(item.CC)}</td>
                                        <td className="px-4 py-3">{formatArray(item.BCC)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </Table>
                    </div>
                </Tabs.Panel>
            </Tabs>

            {/* Modal */}
            <Modal opened={isModalOpen} onClose={closeModal} title="Email Configuration" size="lg" centered>
                <ConfigForm closeModal={closeModal} fetchData={fetchData}/>
            </Modal>
        </div>
    );
};

export default EmailConfig;
