import React, { useState } from 'react';
import Select from 'react-select';
import axios from 'axios';
import { toast } from 'react-toastify';

const ImageUploadModal = ({ showModal, setShowModal, fetchImages }) => {
  const [image, setImage] = useState(null);
  const [category, setCategory] = useState({ value: 'Senior', label: 'Senior' });

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
    if (file && allowedTypes.includes(file.type)) setImage(file);
    else toast.info('Only JPEG, JPG, PNG files are allowed.');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!image) return toast.warning("Select an image to upload.");
    const formData = new FormData();
    formData.append('image', image);
    formData.append('category', category.value);
    try {
      await axios.post(`http://localhost:8080/api/imagetemplate/add/${category.value}`, formData);
      toast.success('Image uploaded successfully.');
      setShowModal(false);
      setImage(null);
      fetchImages();
    } catch (error) {
      toast.error('Image upload failed.');
    }
  };

  return (
    showModal && (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
        <div className="bg-white p-6 rounded shadow-lg relative w-full max-w-md">
          <button onClick={() => setShowModal(false)} className="absolute top-2 right-3 text-lg">&times;</button>
          <form onSubmit={handleSubmit}>
            <label className="block mb-2">Category</label>
            <Select options={[{ value: 'Senior', label: 'Senior' }, { value: 'Junior', label: 'Junior' }]} value={category} onChange={setCategory} />
            <label className="block mt-4 mb-2">Image</label>
            <input type="file" accept=".jpg,.jpeg,.png" onChange={handleImageChange} className="w-full mb-4" />
            <div className="flex justify-end gap-2">
              <button type="submit" className="bg-blue-500 text-white px-4 py-1 rounded">Upload</button>
              <button type="button" onClick={() => setShowModal(false)} className="bg-gray-400 text-white px-4 py-1 rounded">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    )
  );
};

export default ImageUploadModal;
