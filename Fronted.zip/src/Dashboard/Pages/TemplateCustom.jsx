import React, { useState, useEffect } from 'react';
import ImageUploadModal from './ImageUploadModal';
import ImageGallery from './ImageGallery';
import EditorComponent from './EditorComponent';
import axios from 'axios';

const TemplateCustom = () => {
  const [images, setImages] = useState([]);
  const [selectedImage, setSelectedImage] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [showEditor, setShowEditor] = useState(false);

  const fetchImages = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/imagetemplate/get');
      setImages(response.data.images || []);
    } catch (error) {
      console.error('Failed to fetch images.');
    }
  };

  useEffect(() => {
    fetchImages();
  }, []);

  const handleDelete = async (img) => {
    try {
      await axios.delete(`http://localhost:8080/api/imagetemplate/${img.filename}`);
      fetchImages();
    } catch {
      console.error('Failed to delete image.');
    }
  };

  const handleCustomize = (img) => {
    setSelectedImage(img);
    setShowEditor(true);
  };

  return (
    <div className="container mx-auto p-4">
      <button onClick={() => setShowModal(true)} className="bg-blue-600 text-white px-4 mb-4 py-2 rounded">Add Image</button>

      <ImageUploadModal showModal={showModal} setShowModal={setShowModal} fetchImages={fetchImages} />
      <ImageGallery images={images} handleDelete={handleDelete} handleCustomize={handleCustomize} />
      {showEditor && <EditorComponent selectedImage={selectedImage}  />}
    </div>
  );
};

export default TemplateCustom;
