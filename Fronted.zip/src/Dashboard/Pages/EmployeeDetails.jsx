import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { IconInfoCircle } from '@tabler/icons-react';
import { Table, Pagination, TextInput, Button, Select, Modal, FileInput, Tooltip } from '@mantine/core';
import { useDebouncedValue } from '@mantine/hooks';
import * as XLSX from 'xlsx';
import EmployeeAddForm from './Component/EmployeeAddForm';
import EmployeeEditForm from './Component/EmployeeEditForm';
import { toast } from "react-toastify";

const EmployeeDetails = () => {
  const [employeeData, setEmployeeData] = useState([]);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [debouncedSearch] = useDebouncedValue(search, 300);
  const [file, setFile] = useState(null);
  const [modalOpened, setModalOpened] = useState(false);
  const [modalAddOpened, setModalAddOpened] = useState(false);
  const [modalEditOpened, setModalEditOpened] = useState(false);
  const [isAddEmployee, setIsAddEmployee] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [confirmDeleteOpened, setConfirmDeleteOpened] = useState(false);
  const [employeeToDelete, setEmployeeToDelete] = useState(null);

  const bulkexcelsheetDownload = async () => {
    try {
      const headers = [
        ['Sr No', 'EmpId', 'Name', 'Display Name', 'User Email', 'DOB', 'Manager Email', 'HOD Email', 'Category(Senior(Yes)/Junior(No))', 'Leader(Yes/No)', 'HOD(Yes/No)']
      ];

      const workbook = XLSX.utils.book_new();
      const worksheet = XLSX.utils.aoa_to_sheet(headers);

      // ✅ Add a comment to the DOB column (F1 cell because F is the 6th column)
      worksheet['F1'].c = [{
        t: "Please enter date in DD/MM/YYYY format.", // Text of the comment
        a: "System" // Author name (optional)
      }];

      XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

      const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'binary', bookSST: true });

      const s2ab = (s) => {
        const buf = new ArrayBuffer(s.length);
        const view = new Uint8Array(buf);
        for (let i = 0; i < s.length; i++) {
          view[i] = s.charCodeAt(i) & 0xFF;
        }
        return buf;
      };

      const blob = new Blob([s2ab(wbout)], { type: 'application/octet-stream' });

      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'blank_employee_sheet.xlsx';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      toast.error("Something went wrong!");
      console.error(error);
    }
  };

  const fetchEmployee = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/employee/get-emp');
      console.log(response.data);
      setEmployeeData(response.data);
    } catch (error) {
      console.error('Error fetching employee data:', error);
    }
  };

  useEffect(() => {
    fetchEmployee();
  }, []);

  const handleSearchChange = (event) => {
    setSearch(event.target.value);
  };

  const handleFileChange = (file) => {
    setFile(file);
  };

  const handleFileUpload = async () => {
    console.log("Uploading", EmployeeDetails);
    const reader = new FileReader();

    reader.onload = async (e) => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(sheet);
      console.log(jsonData); // Print the extracted data to the console

      // Create a FormData object to send the file
      const formData = new FormData();
      formData.append('file', file);

      try {
        const res = await axios.post('http://localhost:8080/api/employee/add-emp-import', formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });
        if (res.status === 200) {
          setModalOpened(false);
          fetchEmployee();
          toast.success('File uploaded successfully.');
          toast.info('Age should be greater than 19.Also no Blank data will be added from the Excel.');
          console.log('File uploaded successfully');
        }

      } catch (error) {
        toast.error(error.response?.data.message || "Error occurred");
        console.error('Error uploading file:', error);
      }

    };

    if (file) {
      reader.readAsArrayBuffer(file); // Trigger the onload event
    } else {
      console.error("No file selected");
    }
  };

  const filteredData = employeeData.filter((employee) =>
    employee.Name.toLowerCase().includes(debouncedSearch.toLowerCase()) ||
    employee.UserEmail.toLowerCase().includes(debouncedSearch.toLowerCase()) ||
    employee.EmpID.toString().includes(debouncedSearch)
  );


  const paginatedData = filteredData.slice((page - 1) * itemsPerPage, page * itemsPerPage);

  const handleDelete = async (empId) => {
    if (!employeeToDelete) return;
    try {
      const response = await axios.delete(`http://localhost:8080/api/employee/delete-emp/${empId.EmpID}`);
      if (response.status === 200) {
        setConfirmDeleteOpened(false);
        setEmployeeData(employeeData.filter(employee => employee.EmpID !== empId.EmpID));
        toast.success('Employee deleted successfully');
      }
    } catch (error) {
      console.error('Error deleting employee:', error);
      toast.error(error.response?.data.message || "Error occurred");
    }
  };

  const handleEdit = (employee) => {
    setSelectedEmployee(employee);
    setModalEditOpened(true);
  };

  return (
    <>
      <Button variant="outline" color="blue" className="mr-2 mb-2 sm:mb-0 font-Adani" onClick={() => setModalOpened(true)}>Import Employee from Excel</Button>

      <Button variant="outline" color="blue" className="mr-2 mb-2 sm:mb-0 font-Adani" onClick={() => { setModalAddOpened(true); setIsAddEmployee(true); }}>Add new Employee</Button>
      <Button variant="outline" color="blue" className="mr-2 mb-2 sm:mb-0 font-Adani" onClick={bulkexcelsheetDownload}>Bulk Sheet Download</Button>

      <Modal
        opened={modalAddOpened}
        onClose={() => setModalAddOpened(false)}
        title={isAddEmployee ? "Add Employee" : "Import Employee Data"} centered
      >
        {isAddEmployee ? (
          <EmployeeAddForm fetchEmployee={fetchEmployee} onClose={() => setModalAddOpened(false)} open={setModalAddOpened} />
        ) : (
          <>
            <FileInput
              placeholder="Drop your Excel file here"
              onChange={handleFileChange}
            />
            <Button onClick={handleFileUpload} className="mt-4">Submit</Button>
          </>
        )}
      </Modal>

      <Modal
        opened={modalOpened}
        onClose={() => setModalOpened(false)}
        title="Import Employee Data from .xlsx" centered
      >
        <FileInput
          placeholder="Drop your Excel file here"
          classNames={{ input: 'font-Adani' }}
          className="mb-4  font-Adani"
          onChange={handleFileChange}
        />
        <Button className="mr-2 mb-2 sm:mb-0 font-Adani" onClick={handleFileUpload} classNames={{ input: 'font-Adani' }}>Submit</Button>
      </Modal>

      <Modal
        opened={confirmDeleteOpened}
        onClose={() => setConfirmDeleteOpened(false)}
        title="Confirm Delete" centered
      >
        <p>Are you sure you want to delete this employee? This action cannot be undone.</p>
        <div className="flex justify-end mt-4">
          <Button variant="outline" color="gray" className='mr-2 mb-2 sm:mb-0 font-Adani' onClick={() => setConfirmDeleteOpened(false)}>Cancel</Button>
          <Button variant="outline" color="red" className="ml-2 sm:mb-0 font-Adani" onClick={() => handleDelete(employeeToDelete)}>Confirm</Button>
        </div>
      </Modal>

      <Modal
        opened={modalEditOpened}
        onClose={() => {
          setModalEditOpened(false);
          setSelectedEmployee(null);
        }}
        title="Edit Employee"
      >
        {selectedEmployee && (
          <EmployeeEditForm
            employeeData={selectedEmployee}
            fetchEmployee={fetchEmployee}
            onClose={() => setModalEditOpened(false)}
          />
        )}
      </Modal>
      <div className="p-4">
        <TextInput
          placeholder="Search by name,email or employee id"
          value={search}
          onChange={handleSearchChange}
          classNames={{ input: 'font-Adani' }}
          className="mb-4"
        />
        <div className="overflow-x-auto">
          <Table className="min-w-full border font-Adani">
            <thead>
              <tr className="bg-gray-200 text-left whitespace-nowrap">
                <th className="px-4 py-2">Employee Id</th>
                <th className="px-4 py-2">Employee Name</th>
                <th className="px-4 py-2">Employee Email</th>
                <th className="px-4 py-2">DisplayName</th>
                <th className="px-4 py-2 flex items-center">DOB
                  <Tooltip label="DD MM YYYY Format" withArrow>
                    <IconInfoCircle size={18} className="ml-1" />
                  </Tooltip>
                </th>
                <th className="px-4 py-2">ManagerEmail</th>
                <th className="px-4 py-2">HODEmail</th>
                <th className="px-4 py-2">Senior</th>
                <th className="px-4 py-2">Leader</th>
                <th className="px-4 py-2">HOD</th>
                <th className="px-4 py-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {paginatedData.length > 0 ? (
                paginatedData.map((employee) => (
                  <tr key={employee.EmpID} className="border-b hover:bg-gray-100">
                    <td className="px-4 py-2 whitespace-nowrap">{employee.EmpID}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{employee.Name}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{employee.UserEmail}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{employee.DisplayName}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{new Date(employee.DOB).toLocaleDateString('en-GB')}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{employee.ManagerEmail}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{employee.HODEmail}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{employee.IsSenior ? 'Yes' : 'No'}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{employee.IsLeader ? 'Yes' : 'No'}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{employee.IsHOD ? 'Yes' : 'No'}</td>
                    <td className="px-4 py-2 flex space-x-2">
                      <Button variant="outline" color="blue" className="mr-2 mb-2 sm:mb-0 font-Adani" onClick={() => handleEdit(employee)}>Edit</Button>
                      <Button variant="outline" color="red" className="font-Adani" onClick={() => { setEmployeeToDelete(employee); setConfirmDeleteOpened(true); }}>Delete</Button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="10" className="text-center py-4">No employees found</td>
                </tr>
              )}
            </tbody>
          </Table>
        </div>
        <div className="flex justify-between items-center mt-4 " classNames={{ input: 'font-Adani' }} >
          <Select
            value={itemsPerPage}
            onChange={(value) => setItemsPerPage(Number(value))}
            data={[10, 15, 20].map((num) => ({ value: num, label: `${num} per page`, className: 'font-Adani p-2 cursor-pointer hover:bg-gray-200' }))}
            className="w-32 font-Adani"
            classNames={{ input: 'font-Adani' }}
          />
          <Pagination
            className='font-Adani'
            value={page}
            withPages={false}
            page={page}
            onChange={setPage}
            total={Math.ceil(filteredData.length / itemsPerPage)}
          />
        </div>
      </div>
    </>
  );
};

export default EmployeeDetails;