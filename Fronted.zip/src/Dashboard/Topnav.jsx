import React, { useState, useEffect, useRef } from "react";
import { FaBars, FaUserCircle } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import Cookies from "js-cookie";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../Redux/userSlice";
import logo from "../logo.png";
import { toast } from "react-toastify";

const Topnav = ({ toggleSidebar }) => {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const user = useSelector((state) => state.user?.user?.user);

  console.log(user);
  const profileRef = useRef(null);
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setIsProfileOpen(false);
      }
    };

    if (isProfileOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isProfileOpen]);

  const handleLogout = () => {
    Cookies.remove("access_token");
    toast.success("Logged out successfully!");
    dispatch(logout());
    navigate("/login");
  };

  return (
    <header className="bg-blue-500 text-white p-4 flex justify-between items-center w-full">
      <div className="flex items-center space-x-2">
        <button
          onClick={toggleSidebar}
          className="p-2 hover:bg-blue-400 rounded-md"
        >
          <FaBars size={24} />
        </button>

        <img
          src={logo}
          alt="Organization Logo"
          className="w-32 h-auto sm:w-20 md:w-36 lg:w-44 "
        />
      </div>

      {/* Title */}
      <div className="text-lg font-bold hidden md:block">Auto Birthday Wisher</div>

      {/* Profile Section */}
      <div className="relative" ref={profileRef}>
        <button
          onClick={() => setIsProfileOpen((prev) => !prev)}
          className="flex items-center space-x-2 hover:text-blue-300"
        >
          {user && <span className="text-sm font-bold">Hi {user.name}</span>}
          <FaUserCircle size={30} />
        </button>

        {isProfileOpen && (
          <div className="absolute right-0 mt-2 bg-white text-black p-2 rounded-md shadow-lg w-48 z-10">
            <button className="block w-full text-left text-blue-500 hover:bg-blue-100 p-2 rounded-md">
              Edit Profile
            </button>
            <button
              onClick={handleLogout}
              className="block w-full text-left text-red-500 hover:bg-blue-100 p-2 rounded-md"
            >
              Logout
            </button>
          </div>
        )}
      </div>
    </header>
  );
};

export default Topnav;
