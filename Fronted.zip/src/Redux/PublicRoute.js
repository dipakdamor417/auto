import React from 'react';
import { Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';

const PublicRoute = ({ children }) => {
  const token = useSelector((state) => state.auth); // Get token from Redux

  if (token) {
    // If token exists, redirect to the dashboard (or another private route)
    return <Navigate to="/dashboard" />;
  }

  return children; // Otherwise, render the public route
};

export default PublicRoute;
