import { configureStore, combineReducers } from '@reduxjs/toolkit';
import { persistStore, persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage'; // Local storage as the persistence layer
import userReducer from './userSlice'; // Updated import to match the new userSlice file

// Persist configuration
const persistConfig = {
  key: 'root', // Key for the persisted storage
  storage, // Storage to use
  whitelist: ['user'], // Only persist the user slice (updated from 'auth')
};

// Combine reducers (you can add more reducers in the future)
const rootReducer = combineReducers({
  user: persistReducer(persistConfig, userReducer), // Use 'user' instead of 'auth'
  // Add other reducers as needed in the future
});

// Create the store with middleware and persisted reducer
export const store = configureStore({
  reducer: rootReducer, // Combine all reducers here
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: ['persist/PERSIST', 'persist/REHYDRATE'], // Ignore redux-persist actions
        ignoredPaths: [ 'user.token'], // Ignore non-serializable state paths like token
      },
    }),
});

// Create the persistor object to enable persistence
export const persistor = persistStore(store);

export default store;
