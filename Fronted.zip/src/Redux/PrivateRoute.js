import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

// Function to get a cookie by name
const getCookie = (name) => {
  const cookie = document.cookie.split('; ').find(row => row.startsWith(name + '='));
  return cookie ? cookie.split('=')[1] : null;
};

const PrivateRoute = ({ children }) => {
  const navigate = useNavigate();

  useEffect(() => {
    const token = getCookie('access_token');
    if (!token) {
      navigate('/login');  // Redirect to login if no token
    }
  }, [navigate]);

  // If no token, redirect before rendering the children
  const token = getCookie('access_token');
  if (!token) {
    return null;  // Don't render anything until navigation completes
  }

  return children; // Render the protected route if the user is authenticated
};

export default PrivateRoute;
