import express from "express";
import { emailConfigAdd,emailConfigGet ,emailConfigGetByCategory} from "../Controller/emailConfig.js";

const router = express.Router();

router.get("/", emailConfigGet);
router.get("/:category", emailConfigGetByCategory);
router.post("/add", emailConfigAdd);

export default router;
