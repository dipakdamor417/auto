import express from 'express';
import {  ManualtriggerBirthdayMail} from '../Controller/Scheduler.js';
import { getAllEmailLogs } from '../Controller/emaillogs.js';

const router = express.Router();

router.post('/manual', ManualtriggerBirthdayMail);

router.get('/', getAllEmailLogs);

export default router;