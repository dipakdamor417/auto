import express from "express";
import { login, register, otpSend, registerOtpSend, verifyOtp, resetPassword } from "../Controller/Authenticator.js";
import rateLimit from "express-rate-limit";

const router = express.Router();

const otpLimiter = rateLimit({
    windowMs: 24 * 60 * 60 * 1000, 
    max: 10,
    handler: (req, res) => {
        res.status(400).json({ message: "Too many requests, please try again after 24 hours." });
    }
});



router.post("/register", register);
router.post("/login", login);
router.post("/send-otp", otpLimiter, otpSend);
router.post("/send-otp-register", otpLimiter, registerOtpSend);
router.post("/verify-otp", verifyOtp);
router.post("/reset-password", otpLimiter, resetPassword);

export default router;
