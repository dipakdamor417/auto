import express from 'express';
import { employeeBirthdayToday,birthdayCalendar } from '../Controller/dashboard.js';

const router = express.Router();

router.get('/birthdayToday', employeeBirthdayToday);
router.get('/calendar', birthdayCalendar);

export default router;