import express from 'express';
import { imageGet, uploadImage ,deleteImage,imageConfig, imageConfigGet} from '../Controller/templatecustom.js';

const router = express.Router();

console.log("controller");

router.get('/get', imageGet);
router.get('/image-config/get/:filename', imageConfigGet);
router.delete('/:filename', deleteImage);
router.post('/add/:category', uploadImage);
router.post('/image-config', imageConfig);



export default router;