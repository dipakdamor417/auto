import express from 'express';
import { employeeAddExcel,employeeAdd, employeeDelete, employeeGet, employeeUpdate,employeeSingleget } from '../Controller/employee.js';

const router = express.Router();

router.get('/get-emp', employeeGet);
router.get('/get-emp', );
router.get('/:EmpId', employeeSingleget);
router.post('/add-emp-form', employeeAdd);
router.post('/add-emp-import', employeeAddExcel);
router.put('/update-emp', employeeUpdate);
router.delete('/delete-emp/:EmpID', employeeDelete);

export default router;