import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import bodyParser from "body-parser";
import cors from 'cors';
import employee from './Routes/employee.js';
import authRoute from './Routes/authrouter.js';
import dashboard from './Routes/dashboard.js';
import emailConfig from './Routes/emailConfig.js';
import templateCustom from './Routes/templatecustom.js';
import Scheduler from './Routes/Scheduler.js';
import Agenda from 'agenda';
import moment from 'moment-timezone';
import { sendAutoBirthdayMail } from './Controller/Scheduler.js';

dotenv.config();

const app = express();
const port = process.env.PORT || 8080;

app.use(express.json());

app.use(bodyParser.json({ limit: '80mb', extended: true }));
app.use(bodyParser.urlencoded({ limit: '80mb', extended: true }));

app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true,
}));




mongoose.connect("mongodb://127.0.0.1:27017/Dipak")
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Could not connect to MongoDB', err));

app.use("/api/auth", authRoute);
app.use("/api/dashboard", dashboard);
app.use("/api/employee", employee);
app.use("/api/emailconfig", emailConfig);
app.use("/api/imagetemplate", templateCustom);
app.use("/api/scheduler", Scheduler);

const agenda = new Agenda({ db: { address: 'mongodb://127.0.0.1:27017/Dipak' } });

agenda.define('sendAutoBirthdayMail', async job => {
  console.log(`Running job at IST time: ${moment().tz("Asia/Kolkata").format()}`);
  await sendAutoBirthdayMail();
});

agenda.on('ready', async () => {
  console.log('Agenda started successfully');

  await agenda.start();
  await agenda.schedule(moment().tz("Asia/Kolkata").set({ hour: 11, minute: 0 }).toDate(), 'sendAutoBirthdayMail');
  // Retry every 15 minutes until 10 AM
  for (let i = 1; i <= 4; i++) {
    await agenda.schedule(`11:${i * 15} AM`, 'sendAutoBirthdayMail');
  }
});

agenda.on('error', err => {
  console.error('Agenda connection error:', err);
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
