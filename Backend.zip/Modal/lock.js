import mongoose from 'mongoose';

const lockSchema = new mongoose.Schema({
  type: {
    type: String,
    required: true,
    unique: true,
  },
  lockedAt: {
    type: Date,
    required: true,
  },
});


const Lock = mongoose.model('Lock', lockSchema);

export default Lock;


