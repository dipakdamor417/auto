import mongoose from 'mongoose';

const emailCustomizationSchema = new mongoose.Schema({
  category: { type: String, enum: ['Senior', 'Junior'], required: true },
  CC: { type: [String], required: true },
  BCC: { type: [String], required: true }
});

const EmailCustomization = mongoose.model('EmailCustomization', emailCustomizationSchema);
export default EmailCustomization;