import mongoose from 'mongoose';

const ImageConfigSchema = new mongoose.Schema({
  backgroundImage: { type: String, required: true },
  texts: [
    {
      text: { type: String, required: true },
      x: { type: Number, required: true },
      y: { type: Number, required: true },
      fontSize: { type: Number, default: 24 },
      fontFamily: { type: String, default: 'Arial' },
      fill: { type: String, default: '#ffffff' }  // Font color
    }
  ]
}, { timestamps: true });

const ImageConfig = mongoose.model('ImageConfig', ImageConfigSchema);

export default ImageConfig;
