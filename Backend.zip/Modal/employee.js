import mongoose from 'mongoose';

const gmailValidator = {
  validator: function (v) {
    return /^[^\s@]+@(gmail\.com|adani\.com|ptct\.net)$/.test(v);
  },
  message: props => `${props.value} is not a valid email domain address!`
};

const employeeSchema = new mongoose.Schema({
  EmpID: { type: Number, unique: true, required: true },
  Name: { type: String, required: true },
  DisplayName: { type: String, required: true },
  UserEmail: { type: String, required: true, validate: gmailValidator },
  ManagerEmail: { type: String, required: true, validate: gmailValidator },
  HODEmail: { type: String, required: true, validate: gmailValidator },
  DOB: { type: Date, required: true },
  IsSenior: { type: Boolean, required: true },
  IsLeader: { type: Boolean, required: true },
  IsHOD: { type: Boolean, required: true },
  IsActive: { type: Boolean, required: true }
});

const Employee = mongoose.model('Employee', employeeSchema);
export default Employee;
