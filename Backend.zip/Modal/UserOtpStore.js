import mongoose from "mongoose";

const UserOtpStoreSchema = new mongoose.Schema({
    email: {
        type: String,
        required: true,
        unique: true
    },
    otp: {
        type: Number,
        required: true
    },
    isUsed: {
        type: Boolean,
        default: false
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

UserOtpStoreSchema.index({ createdAt: 1 }, { expireAfterSeconds: 120 });

const UserOtpStore = mongoose.model('UserOtpStore', UserOtpStoreSchema);

export default UserOtpStore;
