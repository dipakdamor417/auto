import mongoose from 'mongoose';

const emailLogsSchema = new mongoose.Schema({
    EmailLogID: {
        type: mongoose.Schema.Types.ObjectId,
        default: new mongoose.Types.ObjectId(),
    },
    EmpID: {
        type: String,
        required: true,
    },
    UserEmail: {
        type: String,
        required: true,
    },
    DisplayName: {
        type: String,
        required: true,
    },
    EmailStatus: {
        type: Boolean,
        required: true,
    },
    ErrorDetails: {
        type: String,
    },
    SentTimestamp: {
        type: Date,
        required: true,
    },
});

const EmailLogs = mongoose.model('EmailLogs', emailLogsSchema);
export default EmailLogs;