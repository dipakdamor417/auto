import Employee from '../Modal/employee.js';
import EmailCustomization from '../Modal/emailcustom.js';
import fs from 'fs';
import xlsx from 'xlsx';
import formidable from 'formidable';

const allowedDomains = ['adani.com', 'gmail.com', 'ptct.net'];

const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) return false;
    const domain = email.split('@')[1];
    return allowedDomains.includes(domain);
};

const calculateAge = (dob) => {
    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
};

const validateEmployeeRow = async (data) => {
    const { EmpID, Name, UserEmail, DOB, ManagerEmail, HODEmail } = data;

    if (!EmpID || !Name || !UserEmail || !DOB) {
        throw new Error('EmpID, Name, UserEmail, and DOB are required.');
    }

    for (const [key, email] of [["UserEmail", UserEmail], ["ManagerEmail", ManagerEmail], ["HODEmail", HODEmail]]) {
        if (email && !isValidEmail(email)) throw new Error(`Invalid ${key} format or domain.`);
    }

    if (isNaN(Date.parse(DOB))) {
        throw new Error('DOB must be a valid date.');
    }

    const age = calculateAge(DOB);
    if (age < 19) {
        throw new Error('Employee must be at least 19 years old.');
    }

    const existingEmail = await Employee.findOne({ UserEmail, IsActive: true });
    if (existingEmail && existingEmail.EmpID !== data.EmpID) {
        throw new Error('UserEmail already exists.');
    }
};

// Main controller
export const employeeAddExcel = async (req, res) => {
    console.log("API Called");

    const form = formidable({ maxFileSize: 10 * 1024 * 1024 }); // Max file size: 10MB

    form.parse(req, async (err, fields, files) => {
        if (err) {
            return res.status(400).json({ message: 'Error parsing the file', error: err });
        }

        const file = files.file?.[0];

        if (!file || !file.filepath) {
            return res.status(400).json({ message: 'File not found or invalid file path' });
        }

        try {
            const workbook = xlsx.readFile(file.filepath);
            const sheetName = workbook.SheetNames[0];
            const sheet = workbook.Sheets[sheetName];
            const jsonData = xlsx.utils.sheet_to_json(sheet, { header: 1, raw: false });

            if (jsonData.length < 2) {
                return res.status(400).json({ message: 'Excel file format is invalid or empty' });
            }

            const expectedHeaders = [
                'EmpId', 'Name', 'Display Name', 'User Email', 'DOB',
                'Manager Email', 'HOD Email', 'Category(Senior(Yes)/Junior(No))', 'Leader(Yes/No)', 'HOD(Yes/No)'
            ];

            const actualHeaders = jsonData[0].slice(1);

            const mismatchedHeaders = [];
            expectedHeaders.forEach((expected, index) => {
                if (expected !== actualHeaders[index]) {
                    mismatchedHeaders.push({
                        columnIndex: index + 1,
                        shouldBe: expected,
                        found: actualHeaders[index] || 'Missing'
                    });
                }
            });

            if (mismatchedHeaders.length > 0) {
                const formattedMismatches = mismatchedHeaders.map(mismatch =>
                    `Column ${mismatch.columnIndex}: Expected "${mismatch.shouldBe}" but found "${mismatch.found}"`
                ).join('\n');
                return res.status(400).json({
                    message: `Excel column titles do not match the expected format:\n${formattedMismatches}`
                });
            }

            console.log("Headers match correctly!");

            let skippedRows = 0;
            let insertedCount = 0;
            let modifiedCount = 0;

            for (const [index, row] of jsonData.slice(1).entries()) {
                console.log(`Checking Row ${index + 2}:`, row);

                if (!Array.isArray(row) || row.length < 11 || row.includes(undefined) || row.some(cell => cell === null || cell?.toString().trim() === '')) {
                    console.log(`Skipping Row ${index + 2}: Contains empty/null values.`);
                    skippedRows++;
                    continue;
                }

                const employeeData = {
                    EmpID: row[1]?.trim(),
                    Name: row[2]?.trim(),
                    DisplayName: row[3]?.trim(),
                    UserEmail: row[4]?.trim(),
                    DOB: (() => {
                        const excelDate = row[5];
                        if (typeof excelDate === 'number') {
                            const utcDays = Math.floor(excelDate - 25569);
                            const utcValue = utcDays * 86400 * 1000;
                            const date = new Date(utcValue);
                            return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
                        } else if (typeof excelDate === 'string' && /^\d{2}\/\d{2}\/\d{4}$/.test(excelDate)) {
                            const [day, month, year] = excelDate.split('/').map(Number);
                            return new Date(Date.UTC(year, month - 1, day));
                        } else {
                            const parsedDate = new Date(excelDate);
                            return new Date(Date.UTC(parsedDate.getFullYear(), parsedDate.getMonth(), parsedDate.getDate()));
                        }
                    })(),             
                    ManagerEmail: row[6]?.trim(),
                    HODEmail: row[7]?.trim(),
                    IsSenior: row[8]?.trim().toLowerCase() === 'yes',
                    IsLeader: row[9]?.trim().toLowerCase() === 'yes',
                    IsHOD: row[10]?.trim().toLowerCase() === 'yes',
                    IsActive: true
                };

                try {
                    await validateEmployeeRow(employeeData);

                    const updatedEmployee = await Employee.findOneAndUpdate(
                        { EmpID: employeeData.EmpID },
                        employeeData,
                        { upsert: true, new: true }
                    );

                    if (updatedEmployee) {
                        if (updatedEmployee.isNew) insertedCount++;
                        else modifiedCount++;
                    }
                } catch (error) {
                    console.log(`Skipping Row ${index + 2} due to validation error: ${error.message}`);
                    skippedRows++;
                }
            }

            res.status(200).json({
                message: 'File uploaded and data processed successfully',
                insertedRecords: insertedCount,
                modifiedRecords: modifiedCount,
                skippedRecords: skippedRows,
            });

        } catch (error) {
            console.error("Error processing the file:", error);
            res.status(500).json({ message: 'Error processing the file', error });
        } finally {
            fs.unlink(file.filepath, (err) => {
                if (err) console.error('Error deleting temporary file:', err);
            });
        }
    });
};

export const employeeAdd = async (req, res) => {
    const {
        EmpID,
        Name,
        DisplayName,
        UserEmail,
        DOB,
        ManagerEmail,
        HODEmail,
        IsSenior,
        IsLeader,
        IsHOD,
        IsActive
    } = req.body;

    console.log(req.body);

    const allowedDomains = ['adani.com', 'gmail.com'];

    const isValidEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) return false;

        const domain = email.split('@')[1];
        return allowedDomains.includes(domain);
    };

    const calculateAge = (dob) => {
        const birthDate = new Date(dob);
        const today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        const m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        return age;
    };

    try {
        console.log("EmployeeAdd");
        if (!EmpID || !Name || !UserEmail || !DOB) {
            return res.status(400).json({ message: 'EmpID, Name, UserEmail, and DOB are required.' });
        }

        for (const [key, email] of [["UserEmail", UserEmail], ["ManagerEmail", ManagerEmail], ["HODEmail", HODEmail]]) {
            if (email && !isValidEmail(email)) return res.status(400).json({ message: `Invalid ${key} format or domain.` });
        }

        if (isNaN(Date.parse(DOB))) {
            return res.status(400).json({ message: 'DOB must be a valid date.' });
        }
        const age = calculateAge(DOB);
        if (age < 19) {
            return res.status(400).json({ message: 'Employee must be at least 19 years old.' });
        }

        // Check if UserEmail already exists
        const existingEmployee = await Employee.findOne({ UserEmail, IsActive: true });
        if (existingEmployee) {
            return res.status(400).json({ message: 'UserEmail already exists.' });
        }

        // Check if EmpID already exists
        const existingEmpId = await Employee.findOne({ EmpID });
        if (existingEmpId) {
            return res.status(400).json({ message: 'EmpID already exists.' });
        }

        // Create and save employee
        const newEmployee = new Employee({
            EmpID,
            Name,
            DisplayName,
            UserEmail,
            DOB,
            ManagerEmail,
            HODEmail,
            IsSenior,
            IsLeader,
            IsHOD,
            IsActive: true
        });

        await newEmployee.save();

        res.status(200).json({ message: 'Employee added successfully', employee: newEmployee });

    } catch (error) {
        console.error('Error adding employee:', error);

        if (error.name === "ValidationError") {
            const errors = Object.values(error.errors).map(err => err.message);
            return res.status(400).json({ message: errors.join(", ") });
        }

        res.status(500).json({ message: 'Internal server error' });
    }
};


export const employeeGet = async (req, res) => {
    try {
        const employees = await Employee.find({ IsActive: true });
        res.status(200).json(employees);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching employees', error });
    }
};

export const employeeSingleget = async (req, res) => {
    const empId = req.params.EmpId;
    console.log(empId);
    const employee = await Employee.findOne({ EmpID: empId, IsActive: true });

    if (employee) {
        // Format the DOB field
        const formattedEmployee = {
            ...employee._doc,
            DOB: new Date(employee.DOB).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })
        };
        res.status(200).json(formattedEmployee);
    } else {
        res.status(404).json({ message: 'Employee not found' });
    }
};
// Get a single employee by ID
export const getEmployeeById = async (req, res) => {
    try {
        const employee = await Employee.findById(req.params.id, { IsActive: true });
        if (!employee) {
            return res.status(404).json({ message: 'Employee not found' });
        }
        res.status(200).json(employee);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching employee', error });
    }
};



export const employeeUpdate = async (req, res) => {
    const {
        EmpID,
        Name,
        DisplayName,
        UserEmail,
        DOB,
        ManagerEmail,
        HODEmail,
        IsSenior,
        IsLeader,
        IsHOD,
        IsActive
    } = req.body;

    const allowedDomains = ['adani.com', 'gmail.com'];

    const isValidEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) return false;
        const domain = email.split('@')[1];
        return allowedDomains.includes(domain);
    };

    const calculateAge = (dob) => {
        const birthDate = new Date(dob);
        const today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        const m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        return age;
    };

    try {
        console.log("Updating", req.body);

        if (!EmpID || !Name || !UserEmail || !DOB) {
            return res.status(400).json({ message: 'EmpID, Name, UserEmail, and DOB are required.' });
        }

        for (const [key, email] of [["UserEmail", UserEmail], ["ManagerEmail", ManagerEmail], ["HODEmail", HODEmail]]) {
            if (email && !isValidEmail(email)) {
                return res.status(400).json({ message: `Invalid ${key} format or domain.` });
            }
        }

        if (isNaN(Date.parse(DOB))) {
            return res.status(400).json({ message: 'DOB must be a valid date.' });
        }

        const age = calculateAge(DOB);
        if (age < 19) {
            return res.status(400).json({ message: 'Employee must be at least 19 years old.' });
        }

        const employee = await Employee.findOneAndUpdate(
            { EmpID: EmpID, IsActive: true },
            {
                Name,
                DisplayName,
                UserEmail,
                DOB,
                ManagerEmail,
                HODEmail,
                IsSenior,
                IsLeader,
                IsHOD,
                IsActive
            },
            { new: true, runValidators: true }
        );

        if (!employee) {
            return res.status(404).json({ message: 'Employee not found' });
        }

        res.status(200).json({ message: 'Employee updated successfully', employee });

    } catch (error) {
        console.error('Error updating employee:', error);

        if (error.name === "ValidationError") {
            const errors = Object.values(error.errors).map(err => err.message);
            return res.status(400).json({ message: errors.join(", ") });
        }

        res.status(400).json({ message: 'Error updating employee', error });
    }
};

export const employeeDelete = async (req, res) => {
    try {
        console.log(req.params.EmpID);
        const employeesingle = await Employee.findOne({ EmpID: req.params.EmpID });
        console.log(employeesingle);

        if (!employeesingle) {
            return res.status(404).json({ message: 'Employee not found' });
        }

        const userEmail = employeesingle.UserEmail;
        console.log(userEmail);

        await EmailCustomization.updateMany(
            { CC: userEmail },
            { $pull: { CC: userEmail } }
        );

        await EmailCustomization.updateMany(
            { BCC: userEmail },
            { $pull: { BCC: userEmail } }
        );

        const employee = await Employee.findOneAndUpdate(
            { EmpID: req.params.EmpID },
            { IsActive: false },
            { new: true }
        );
        if (!employee) {
            return res.status(404).json({ message: 'Employee not found' });
        }

        res.status(200).json({ message: 'Employee deleted successfully', employee });
    } catch (error) {
        res.status(500).json({ message: 'Error deactivating employee', error });
    }
};