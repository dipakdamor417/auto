import Employee from '../Modal/employee.js';
import EmailLogs from '../Modal/emaillogs.js';
import Lock from '../Modal/lock.js';
import nodemailer from 'nodemailer';
import mongoose from 'mongoose';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import path from 'path';
import fs from 'fs';
import EmailCustomization from '../Modal/emailcustom.js';
import ImageConfig from '../Modal/imageconfig.js';
import pkg from '@napi-rs/canvas';
const { createCanvas, loadImage, GlobalFonts } = pkg;

function drawMultilineText(ctx, text, x, y, maxWidth, lineHeight, topMargin = 20) {
    const lines = text.split('\n'); // Split text into lines based on newline characters
    let currentY = y + topMargin; // Add top margin to the initial y position

    lines.forEach(line => {
        const words = line.split(' ');
        let currentLine = '';

        words.forEach((word, index) => {
            const testLine = currentLine + word + ' ';
            const metrics = ctx.measureText(testLine);
            const testWidth = metrics.width;

            if (testWidth > maxWidth && index > 0) {
                ctx.fillText(currentLine, x, currentY);
                currentLine = word + ' ';
                currentY += lineHeight;
            } else {
                currentLine = testLine;
            }
        });

        if (currentLine.trim() !== '') {
            ctx.fillText(currentLine, x, currentY);
            currentY += lineHeight;
        } else {
            currentY += lineHeight; // Add extra space for blank lines
        }
    });
}

const sendEmail = async (displayname, toEmails, subject, message, isSenior, ccEmails = [], bccEmails = []) => {
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = dirname(__filename);

    GlobalFonts.registerFromPath(path.join(__dirname, 'Adani.ttf'), 'Adani Regular'); // ✅
    GlobalFonts.registerFromPath(path.join(__dirname, 'BaguetScript.ttf'), 'Baguet Script'); // ✅

    console.log('Adani Font Path:', path.join(__dirname, 'Adani.ttf'));
    console.log('Baguet Script Font Path:', path.join(__dirname, 'BaguetScript.ttf'));
    console.log("Preparing to send email...");

    try {
        if (!displayname || displayname.trim() === '') {
            throw new Error('No display name provided. Cannot generate email.');
        }

        const uploadsDir = path.join(__dirname, '..', 'uploads');
        const imageFiles = fs.readdirSync(uploadsDir).filter(file =>
            /\.(jpg|jpeg|png|gif)$/i.test(file)
        );

        const imageFileName = imageFiles.find(file =>
            file.toLowerCase().includes(isSenior ? 'senior' : 'junior')
        );

        if (!imageFileName) {
            throw new Error(`No background image found for ${isSenior ? 'Senior' : 'Junior'} recipient.`);
        }

        const imagePath = path.join(uploadsDir, imageFileName);

        const backgroundImageData = await loadImage(imagePath);
        const canvas = createCanvas(backgroundImageData.width, backgroundImageData.height);
        const ctx = canvas.getContext('2d');
        ctx.drawImage(backgroundImageData, 0, 0);

        const imageConfig = await ImageConfig.findOne({ backgroundImage: imageFileName });
        if (!imageConfig) {
            throw new Error('Image configuration not found in database.');
        }

        const { texts } = imageConfig;

        const customizedCanvas = createCanvas(backgroundImageData.width * 2, backgroundImageData.height * 2); // Double resolution
        const customCtx = customizedCanvas.getContext('2d');
        customCtx.scale(2, 2);  // Scale down later for better text quality
        customCtx.drawImage(backgroundImageData, 0, 0);

        for (const textConfig of texts) {
            const dynamicText = textConfig.text.replace('{{name}}', displayname);
            const fontSize = textConfig.fontSize || 30;
            customCtx.font = `${fontSize}px "${textConfig.fontFamily || 'Adani Regular'}"`;
            customCtx.fillStyle = textConfig.fill || 'black';

            const lineHeight = fontSize * 1;
            const maxWidth = textConfig.maxWidth || 600;
            drawMultilineText(customCtx, dynamicText, textConfig.x, textConfig.y, maxWidth, lineHeight);
        }

        const imageBuffer = customizedCanvas.toBuffer('image/png');

        const transporter = nodemailer.createTransport({
            service: 'gmail',
            port: 465,
            secure: true,
            auth: {
                user: process.env.EMAIL,
                pass: process.env.PASSWORD,
            },
            tls: { rejectUnauthorized: false },
            timeout: 10000
        });

        const mailOptions = {
            from: process.env.EMAIL,
            to: toEmails.length > 0 ? toEmails : undefined,
            subject,
            html: `
                <div>
                    <p>${message}</p>
                    <img src="cid:unique@nodemailer" style="width:100%; max-width:600px;" />
                </div>
            `,
            cc: ccEmails.length > 0 ? ccEmails : undefined,
            bcc: bccEmails.length > 0 ? bccEmails : undefined,
            attachments: [
                {
                    filename: imageFileName,
                    content: imageBuffer,
                    cid: 'unique@nodemailer'
                }
            ]
        };

        const info = await transporter.sendMail(mailOptions);
        console.log('Email successfully sent:', info.response);
        return { success: true, message: 'Email sent successfully.' };

    } catch (err) {
        console.error('Failed to send email:', err.message);
        return { success: false, message: err.message };
    }
};




//Auto Logic for Birthday Mail
export const sendAutoBirthdayMail = async () => {
    console.log("📧 Birthday Mail Process Started");

    const today = new Date();
    const todayMonth = today.getMonth();
    const todayDate = today.getDate();
    console.log("Today Month:", todayMonth + 1, "Today Date:", todayDate);

    try {
        const employees = await Employee.find({
            $expr: {
                $and: [
                    { $eq: [{ $month: '$DOB' }, todayMonth + 1] },
                    { $eq: [{ $dayOfMonth: '$DOB' }, todayDate] },
                ],
            },
            IsActive: true
        });

        const leaders = await Employee.find({
            IsLeader: true,
            IsActive: true
        });
        const HODS = await Employee.find({
            IsLeader: false,
            IsHOD: true,
            IsActive: true
        });

        const leaderEmails = leaders.map(leader => leader.UserEmail);
        const hodEmails = HODS.map(HODS => HODS.UserEmail);
        console.log("Leader Emails: Leader", hodEmails, leaderEmails);
        console.log(employees);

        const todayStart = new Date(today.setHours(0, 0, 0, 0));
        const todayEnd = new Date(today.setHours(23, 59, 59, 999));

        const emailTasks = employees.map(async (employee) => {
            const existingLog = await EmailLogs.findOne({
                EmpID: employee.EmpID,
                SentTimestamp: { $gte: todayStart, $lt: todayEnd },
                EmailStatus :true
            });

            
            if (existingLog) {
                console.log(`⏩ Email already sent to ${employee.DisplayName}`);
                return;
            }

            const emailLogID = new mongoose.Types.ObjectId();

            const inserted = await EmailLogs.findOneAndUpdate(
                {
                    EmpID: employee.EmpID,
                    SentTimestamp: { $gte: todayStart, $lt: todayEnd }
                },
                {
                    $setOnInsert: {
                        EmpID: employee.EmpID,
                        UserEmail: employee.UserEmail,
                        DisplayName: employee.DisplayName,
                        EmailStatus: false,
                        SentTimestamp: new Date(),
                        EmailLogID: emailLogID
                    }
                },
                {
                    upsert: true,
                    new: false 
                }
            );
            
            if (inserted) {
                console.log(`⏩ Email already sent or in-progress for ${employee.DisplayName}`);
                return;
            }
            const {
                UserEmail: email,
                DisplayName: displayName,
                IsSenior: isSenior,
                IsLeader: isLeader,
                IsHOD: isHOD,
                ManagerEmail: managerEmail,
                HODEmail: hodEmail
            } = employee;

            const customization = await EmailCustomization.findOne({
                category: isSenior ? "Senior" : "Junior"
            });

            let toEmails = [email].filter(Boolean);
            let ccEmails = [managerEmail, hodEmail].filter(Boolean);
            let bccEmails = [];

            if (!isSenior) {
                ccEmails = [...ccEmails, ...(customization?.CC || [])];
            } else {
                if (isLeader || isHOD) {
                    ccEmails = [...ccEmails, ...(customization?.CC || []), ...leaderEmails];
                    bccEmails = [...hodEmails, ...(customization?.BCC || [])];
                } else {
                    ccEmails = [...ccEmails, ...(customization?.CC || [])];
                }
            }

            const seen = new Set();

            toEmails = toEmails.filter(e => !seen.has(e) && seen.add(e));
            ccEmails = ccEmails.filter(e => !seen.has(e) && seen.add(e));
            bccEmails = bccEmails.filter(e => !seen.has(e) && seen.add(e));


            console.log("To Emails:", toEmails,ccEmails,bccEmails,"For",employee.DisplayName);

            const subject = "Happy Birthday!!!";
            const message = `
                Happy Birthday! 🎉<br><br>
                <small>Note: This is an auto-generated email for testing purposes. Please do not reply.</small><br><br>
            `;

            try {
                const result = await sendEmail(displayName, toEmails, subject, message, isSenior, ccEmails, bccEmails);

                await EmailLogs.updateOne(
                    { EmailLogID: emailLogID },
                    {
                        $set: {
                            EmailStatus: result.success,
                            ErrorDetails: result.success ? null : result.message,
                            SentTimestamp: new Date()
                        }
                    }
                );

                console[result.success ? "log" : "error"](
                    `${result.success ? "✅" : "❌"} Email ${result.success ? "sent to" : "failed for"} ${displayName}${result.success ? "" : `: ${result.message}`}`
                );
            } catch (error) {
                await EmailLogs.updateOne(
                    { EmailLogID: emailLogID },
                    {
                        $set: {
                            EmailStatus: false,
                            ErrorDetails: error.message,
                            SentTimestamp: new Date()
                        }
                    }
                );
                console.error(`❌ Error sending email to ${displayName}: ${error.message}`);
            }
        });

        await Promise.allSettled(emailTasks);
        console.log("✅ All email tasks completed.");
    } catch (error) {
        console.error("🚨 Error in sendAutoBirthdayMail:", error);
    }
};


export const ManualtriggerBirthdayMail = async (req, res) => {
    const existingLock = await Lock.findOne({ type: "birthday-mail" });

    console.log("Existing lock:", existingLock);

    if (existingLock && Date.now() - new Date(existingLock.lockedAt).getTime() < 10 * 60 * 1000) {
        return res.status(429).json({ message: "Birthday mail is already being sent. Please wait..." });
    }

    try {
        console.log("Creating or updating lock...");

        await Lock.findOneAndUpdate(
            { type: "birthday-mail" },
            { lockedAt: new Date() },
            { upsert: true, new: true }
        ).then(result => console.log("Upserted Lock:", result));

        console.log("Lock saved, sending mail...");

        await sendAutoBirthdayMail();

        res.json({ message: "Birthday emails sent successfully." });
    } catch (error) {
        console.error("Error in manual trigger:", error);
        res.status(500).json({ message: "Failed to send birthday emails", error: error.message });
    } finally {
        console.log("Deleting lock...");
        await Lock.deleteOne({ type: "birthday-mail" });
    }
};
