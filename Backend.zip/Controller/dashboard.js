import Employee from '../Modal/employee.js';

export const employeeBirthdayToday = async (req, res) => {
    try {
        const today = new Date();
        const todayMonth = today.getMonth() + 1; // Months are zero-based
        const todayDate = today.getDate();

        const employees = await Employee.find({ IsActive: true });
        const birthdayEmployees = employees.filter(employee => {
            const dob = new Date(employee.DOB);
            return dob.getMonth() + 1 === todayMonth && dob.getDate() === todayDate;
        });

        console.log("",birthdayEmployees);

        res.status(200).json(birthdayEmployees);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching employees', error });
    }
};

export const birthdayCalendar = async (req, res) => {
    try {
        const employees = await Employee.find({ IsActive: true });

        const events = employees.map(employee => {
            const startDate = new Date(employee.DOB);
            const endDate = new Date(startDate);
            endDate.setFullYear(startDate.getFullYear() + 130);
        
            return {
                id: employee.EmpID,
                text: `${employee.DisplayName}'s Birthday`,
                start_date: startDate.toISOString().split('T')[0] + ' 00:00',
                duration: 86400,
                end_date: endDate.toISOString().split('T')[0] + ' 00:00',
                rrule: 'FREQ=YEARLY;INTERVAL=1'
            };
        });
        
        console.log(events);
        
        res.json(events);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};