import EmailCustomization from '../Modal/emailcustom.js';


export const emailConfigGet = async (req, res) =>{
    try {
      const emailConfigs = await EmailCustomization.find();
    
      res.status(200).json(emailConfigs);
    } catch (error) {
      console.error('Error fetching email conFfigurations', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  };
  export const emailConfigGetByCategory = async (req, res) => {
      const { category } = req.params;
    try {
        const emailConfigs = await EmailCustomization.find({ category: category });
    
        res.status(200).json(emailConfigs);
    } catch (error) {
        console.error('Error fetching email configurations', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};


  export const emailConfigAdd = async (req, res) => {
    try {
      const { category, CC, BCC } = req.body.formData;
     
      // Check if the category already exists
      const existingConfig = await EmailCustomization.findOne({ category: category.value });
      if (existingConfig) {
        return updateEmailConfig(req, res, existingConfig);
      }
  
      // Create a new email customization document
      const newEmailConfig = new EmailCustomization({
        category: category.value,
        CC: CC.map(cc => cc.value),
        BCC: BCC.map(bcc => bcc.value)
      });
  
      const saved = await newEmailConfig.save();
      if (saved) {
        res.status(200).json({ message: 'Email configuration added successfully' });
      } else {
        res.status(201).json({ message: 'Email configuration not saved.' });
      }
    } catch (error) {
      console.error('Error adding email configuration', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  };

  const updateEmailConfig = async (req, res, existingConfig) => {
    try {
        const { CC, BCC } = req.body.formData;

        existingConfig.CC = CC.map(cc => cc.value);
        existingConfig.BCC = BCC.map(bcc => bcc.value);

        const updated = await existingConfig.save();
        if (updated) {
            res.status(200).json({ message: 'Email configuration updated successfully' });
        } else {
            res.status(201).json({ message: 'Email configuration not updated.' });
        }
    } catch (error) {
        console.error('Error updating email configuration', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};