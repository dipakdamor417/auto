import EmailLogs from '../Modal/emaillogs.js'

export const getAllEmailLogs = async (req, res) => {
    try {
        const emailLogs = await EmailLogs.find();
        res.status(200).json(emailLogs);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching email logs', error: error.message });
    }
};