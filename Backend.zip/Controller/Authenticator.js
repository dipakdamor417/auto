import User from "../Modal/UserSchema.js";
import UserOtpStore from "../Modal/UserOtpStore.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import nodemailer from "nodemailer";


const generateOtp = () => Math.floor(100000 + Math.random() * 900000);

const sendEmail = async (email, subject, message) => {
    const transporter = nodemailer.createTransport({
        service: "gmail",
        port: 465,
        secure: true,
        auth: {
            user: process.env.EMAIL,
            pass: process.env.PASSWORD,
        },
        tls: {
            rejectUnauthorized: false
        }
    });

    const mailOptions = {
        from: process.env.EMAIL,
        to: email,
        subject,
        html: message,
    };
    return transporter.sendMail(mailOptions);
};

// Register User
export const register = async (req, res, next) => {
    try {
        let { name, email, password, otp } = req.body;
        email = email.trim();
        password = password.trim();

        if (!email || !/\S+@\S+\.\S+/.test(email)) {
            return res.status(400).json({ message: "Invalid email format." });
        }

        const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,18}$/;
        if (!password || !passwordRegex.test(password)) {
            return res.status(400).json({
                message: "Password must be 8-18 characters long, include at least one uppercase letter, one number, and one special character.",
            });
        }

        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: "Email is already registered." });
        }

        // Verify OTP
        const userOtp = await UserOtpStore.findOne({ email });
        if (!userOtp || userOtp.otp !== parseInt(otp) || userOtp.expires < Date.now()) {
            return res.status(400).json({ message: "Invalid or expired OTP." });
        }

        const hashedPassword = bcrypt.hashSync(password, 10);

        const newUser = new User({ name: name.trim(), email, password: hashedPassword });
        await newUser.save();

        await UserOtpStore.deleteOne({ email });

        res.status(200).json({ message: "User registered successfully." });
    } catch (error) {
        console.error("Error in register:", error);
        next(error);
    }
};

// Login User
export const login = async (req, res) => {
    try {
        let { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: "Email and password are required." });
        }
        email = email.trim().toLowerCase();

        const user = await User.findOne({ email });

        if (!user) {
            return res.status(404).json({ error: "User not found." });
        }

        if (!user.isActive) {
            return res.status(403).json({ error: "Your account is inactive. Please contact the administrator." });
        }

        const isCorrect = await bcrypt.compare(password, user.password);
        if (!isCorrect) {
            return res.status(401).json({ error: "Incorrect credentials." });
        }

        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "30d" });

        res.cookie("access_token", token).status(200).json({ message: "Login successful", token, user });
    } catch (err) {
        console.error("Error during login:", err);
        res.status(500).json({ error: "Internal server error." });
    }
};

export const otpSend = async (req, res, next) => {
    try {
        const { username } = req.body;
        console.log("OTP requested for:", username);

        const user = await User.findOne({ email: username });
        if (!user) return res.status(404).json({ message: "User with this email does not exist." });

        const otp = generateOtp();

        await UserOtpStore.updateOne(
            { email: username },
            { otp, createdAt: new Date() },
            { upsert: true }
        );

        const subject = "Login OTP";
        const message = `<p>Your OTP is: <strong>${otp}</strong>. It is valid for 2 minutes.</p>`;

        // Send response immediately and send email in background
        res.status(200).json({ message: "OTP sended successfully." });

        // Send email asynchronously
        setImmediate(async () => {
            try {
                await sendEmail(username, subject, message);
                console.log(`OTP email sent to ${username}`);
            } catch (error) {
                console.error("Error sending OTP email:", error);
            }
        });

    } catch (error) {
        console.error("Error in otpSend:", error);
        next(error);
    }
};



// Send OTP for Registration
export const registerOtpSend = async (req, res, next) => {
    try {
        const { email } = req.body;
        const existingUser = await User.findOne({ email });

        if (existingUser) return res.status(400).json({ message: "User already exists." });

        await UserOtpStore.deleteOne({ email });

        const otp = generateOtp();

        await UserOtpStore.updateOne(
            { email },
            { otp, expires: Date.now() + 10 * 60000 },
            { upsert: true },
            { isUsed: false }
        );

        const subject = "Registration OTP";
        const message = `<p>Your OTP is: <strong>${otp}</strong>. It is valid for 2 minutes.</p>`;

        const response = await sendEmail(email, subject, message);
        if (response) {
            return res.status(200).json({ message: "Otp Sent" });
        }
        else {
            return res.status(400).json({ message: "Otp Sent" });
        }
    } catch (error) {
        console.error("Error in registerOtpSend:", error);
        next(error);
    }
};

export const verifyOtp = async (req, res) => {
    const { email, otp } = req.body;
    console.log("Verifying OTP...", email, otp);

    try {
        const otpRecord = await UserOtpStore.findOne({ email: email });

        if (!otpRecord) {
            return res.status(400).json({ message: "No OTP sent to your email." });
        }
        console.log(otpRecord.otp, "Ok:", otp);

        if (String(otpRecord.otp).trim() !== String(otp).trim()) {
            return res.status(400).json({ message: "Invalid OTP. Please retry." });
        }
        if (otpRecord.isUsed) {
            return res.status(400).json({ message: "OTP already used. Request a new one." });
        }

        otpRecord.isUsed = true;
        await otpRecord.save();

        return res.status(200).json({ message: "OTP verified successfully" });
    } catch (error) {
        console.error("Error verifying OTP:", error);
        return res.status(500).json({ message: "Internal server error" });
    }
};


// Reset Password
export const resetPassword = async (req, res, next) => {
    try {
        const { email, newPassword } = req.body;

        const userOtp = await UserOtpStore.findOne({ email });

        if (!userOtp) return res.status(400).json({ message: "No OTP found for this email." });

        const otpExpiryTime = new Date(userOtp.createdAt.getTime() + 2 * 60000);

        if (otpExpiryTime < new Date()) {
            return res.status(400).json({ message: "OTP has expired. Please request a new one." });
        }

        const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,18}$/;
        if (!newPassword || !passwordRegex.test(newPassword)) {
            return res.status(400).json({
                message: "Password must be 8-18 characters long, include at least one uppercase letter, one number, and one special character.",
            });
        }
        const hashedPassword = bcrypt.hashSync(newPassword, 10);
        const user = await User.findOneAndUpdate({ email }, { password: hashedPassword }, { new: true });

        if (!user) return res.status(404).json({ message: "User not found" });

        await UserOtpStore.deleteOne({ email });

        res.status(200).json({ message: "Password reset successfully." });
    } catch (error) {
        console.error("Error in resetPassword:", error);
        next(error);
    }
};
