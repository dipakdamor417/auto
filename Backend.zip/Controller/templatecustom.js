import { fileURLToPath } from 'url';
import { dirname } from 'path';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import ImageConfig from '../Modal/imageconfig.js';
import nodemailer from 'nodemailer';
import { createCanvas, loadImage } from 'canvas';




export const imageConfig = async (req, res) => {
  try {
    const { backgroundImage, texts } = req.body;

    // Check if required fields are present
    if (!backgroundImage || !texts) {
      return res.status(400).json({ message: 'Missing backgroundImage or texts' });
    }

    // Validate the background image
    const imagePath = path.join(__dirname, '..', 'uploads', backgroundImage);
    const imageFileName = backgroundImage.toLowerCase();
    const filesInDir = fs.readdirSync(path.join(__dirname, '..', 'uploads'));

    // Check if the image exists
    const fileExists = filesInDir.some(file => file.toLowerCase() === imageFileName);
    if (!fileExists) {
      return res.status(404).json({ message: 'Image file not found in uploads directory' });
    }

    // Save or update the configuration in the database
    const savedConfig = await ImageConfig.findOneAndUpdate(
      { backgroundImage },
      { backgroundImage, texts },
      { upsert: true, new: true }
    );

    res.status(201).json({
      message: 'Image configuration saved or updated successfully',
      config: savedConfig,
    });
  } catch (err) {
    console.error('Error processing image configuration:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// export const imageConfig = async (req, res) => {
//   try {
//     const { backgroundImage, texts } = req.body;

//     console.log("",texts);
//     // Check if required fields are present
//     if (!backgroundImage || !texts) {
//       return res.status(400).json({ message: 'Missing backgroundImage or texts' });
//     }

//     // Demo recipients (these can be dynamic or fetched from a database)
//     const recipients = [
//       { email: 'dipakdamor417@gmail.com', name: 'Dipak' },
//       { email: 'dipakofficial2020@gmail.com', name: 'Smit' },
//     ];

//     // Validate the background image
//     const imagePath = path.join(__dirname, '..', 'uploads', backgroundImage);
//     const imageFileName = backgroundImage.toLowerCase();
//     const filesInDir = fs.readdirSync(path.join(__dirname, '..', 'uploads'));

//     // Check if the image exists
//     const fileExists = filesInDir.some(file => file.toLowerCase() === imageFileName);
//     if (!fileExists) {
//       return res.status(404).json({ message: 'Image file not found in uploads directory' });
//     }

//     // Save the configuration to the database
//     const savedConfig = await ImageConfig.findOneAndUpdate(
//       { backgroundImage },
//       { backgroundImage, texts },
//       { upsert: true, new: true }
//     );

//     // Load the background image onto the canvas
//     const backgroundImageData = await loadImage(imagePath);
//     const canvas = createCanvas(backgroundImageData.width, backgroundImageData.height);
//     const ctx = canvas.getContext('2d');
//     ctx.drawImage(backgroundImageData, 0, 0);

//     // Loop through the recipients to customize and send emails
//     for (const recipient of recipients) {
//       const customizedCanvas = createCanvas(backgroundImageData.width, backgroundImageData.height);
//       const customCtx = customizedCanvas.getContext('2d');

//       // Draw the background image again
//       customCtx.drawImage(backgroundImageData, 0, 0);

//       // Apply text customization for each recipient
//       for (const textConfig of texts) {
//         // Replace dynamic text placeholders with recipient's name
//         const dynamicText = textConfig.text.replace('{{name}}', recipient.name);

//         // Set font style, size, and color
//         customCtx.font = `${textConfig.fontSize || 32}px ${textConfig.fontFamily || 'Arial'}`;
//         customCtx.fillStyle = textConfig.fill || 'black'; // Use the correct color property (fill)

//         customCtx.fillText(dynamicText, textConfig.x, textConfig.y);
//       }

//       // Convert the canvas to a PNG image buffer
//       const imageBuffer = customizedCanvas.toBuffer('image/png');

//       // Send the email with the customized image attached
//       await sendEmail(recipient.email, 'Customized Birthday Poster', imageBuffer, recipient.name);
//     }

//     res.status(201).json({
//       message: 'Image configuration saved and demo emails sent successfully',
//     });
//   } catch (err) {
//     console.error('Error processing image and email:', err);
//     res.status(500).json({ message: 'Server error' });
//   }
// };

// // Email sending function using Nodemailer
// const sendEmail = async (to, subject, imageBuffer, name) => {
//   const transporter = nodemailer.createTransport({
//     service: 'gmail',
//     auth: {
//       user: process.env.EMAIL,
//       pass: process.env.PASSWORD,
//     },
//   });

//   const mailOptions = {
//     from: process.env.EMAIL,
//     to,
//     subject,
//     html: `<h2>Hey ${name} 🎂</h2><p>Here’s your personalized birthday poster!</p>`,
//     attachments: [
//       {
//         filename: 'birthday-poster.png',
//         content: imageBuffer,
//       },
//     ],
//   };

//   return transporter.sendMail(mailOptions)
//     .then(info => console.log(`Email sent to ${name}:`, info.response))
//     .catch(error => console.error(`Error sending to ${name}:`, error));
// };



export const imageConfigGet = async (req, res) => {
  try {
    const { filename } = req.params;
    const config = await ImageConfig.findOne({ backgroundImage: filename });
    if (!config) {
      return res.status(404).json({ message: 'No config found' });
    }
    res.json(config);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
}


// Get the directory name
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Set up multer for image upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir); // Directory to save the image
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});

const upload = multer({ storage });


export const imageGet = async (req, res) => {
  try {
    const uploadsDir = path.join(__dirname, '..', 'uploads'); // Adjusted path

    fs.readdir(uploadsDir, (err, files) => {
      if (err) {
        return res.status(500).json({ error: 'An error occurred while retrieving the images' });
      }

      const imageFiles = files.filter(file => /\.(jpg|jpeg|png|gif)$/.test(file));
      console.log('Image files:', imageFiles);
    });

    // const uploadsDir = path.join(__dirname, '..', 'uploads'); // Adjusted path
    fs.readdir(uploadsDir, (err, files) => {
      if (err) {
        return res.status(500).json({ error: 'An error occurred while retrieving the images' });
      }

      const imageFiles = files.filter(file => /\.(jpg|jpeg|png|gif)$/.test(file));
     

      // Read and encode image files in base64
      const images = imageFiles.map(file => {
        const filePath = path.join(uploadsDir, file);
        const fileData = fs.readFileSync(filePath, { encoding: 'base64' });
        return {
          filename: file,
          data: `data:image/${path.extname(file).slice(1)};base64,${fileData}`
        };
      });

      res.status(200).json({ images });
    });
  } catch (e) {
    console.error('Error retrieving images:', e);
    res.status(500).json({ error: 'An error occurred while retrieving the images' });
  }
};
export const uploadImage = async (req, res) => {
  try {
    upload.single('image')(req, res, (err) => {
      if (err) {
        res.status(500).json({ error: 'Failed to upload image' });
      }

      const originalFilePath = req.file.path;
      const newFilePath = path.join(req.file.destination, `${req.body.category}.png`);

      fs.rename(originalFilePath, newFilePath, (err) => {
        if (err) {
          console.error('Error renaming file:', err);
          return res.status(500).json({ error: 'Failed to rename file' });
        }
        console.log('File uploaded and renamed successfully:', newFilePath);
        res.status(200).json({ message: 'Image uploaded and renamed successfully', filePath: newFilePath });
      });
    });
  } catch (e) {
    console.error('Error in uploadImage function:', e);
    res.status(500).json({ error: 'An error occurred while uploading the image' });
  }
};


export const deleteImage = async (req, res) => {
  try {
    const { filename } = req.params;
    const filePath = path.join(__dirname, '..', 'uploads', filename);

    fs.unlink(filePath, (err) => {
      if (err) {
        console.error('Error deleting file:', err);
        return res.status(500).json({ error: 'Failed to delete image' });
      }
      console.log('File deleted successfully:', filePath);
      res.status(200).json({ message: 'Image deleted successfully' });
    });
  } catch (e) {
    console.error('Error in deleteImage function:', e);
    res.status(500).json({ error: 'An error occurred while deleting the image' });
  }
};

